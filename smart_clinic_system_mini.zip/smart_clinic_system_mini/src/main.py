import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, request, jsonify
from flask_cors import CORS
from src.models import db
from src.routes.auth import auth_bp
from src.routes.user import user_bp
from src.routes.patient import patient_bp
from src.routes.doctor import doctor_bp
from src.routes.appointment import appointment_bp
from src.routes.visit import visit_bp
from src.routes.prescription import prescription_bp
from src.routes.invoice import invoice_bp
from src.routes.notification import notification_bp
from src.routes.medical_record import medical_record_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
CORS(app)  # تفعيل CORS للسماح بالطلبات من مصادر مختلفة
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# تفعيل قاعدة البيانات
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///smart_clinic.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# تسجيل جميع واجهات البرمجة
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(user_bp, url_prefix='/api/users')
app.register_blueprint(patient_bp, url_prefix='/api/patients')
app.register_blueprint(doctor_bp, url_prefix='/api/doctors')
app.register_blueprint(appointment_bp, url_prefix='/api/appointments')
app.register_blueprint(visit_bp, url_prefix='/api/visits')
app.register_blueprint(prescription_bp, url_prefix='/api/prescriptions')
app.register_blueprint(invoice_bp, url_prefix='/api/invoices')
app.register_blueprint(notification_bp, url_prefix='/api/notifications')
app.register_blueprint(medical_record_bp, url_prefix='/api/medical-records')

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
