// إضافة التفاعلية والحركة للنظام
document.addEventListener('DOMContentLoaded', function() {
    // تهيئة التقويم
    initCalendar();
    
    // تهيئة الرسوم البيانية إذا كانت موجودة
    initCharts();
    
    // إضافة مستمعي الأحداث للنوافذ المنبثقة
    initModals();
    
    // تهيئة جدول المرضى إذا كان موجوداً
    if (document.getElementById('patientsTable')) {
        initPatientsTable();
    }
    
    // تهيئة قائمة المستخدم
    initUserMenu();
    
    // تهيئة زر تبديل اللغة
    initLanguageSwitch();
});

// تهيئة التقويم
function initCalendar() {
    const calendarContainer = document.getElementById('calendar');
    if (!calendarContainer) return;
    
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    
    // عرض الشهر الحالي
    renderCalendar(currentMonth, currentYear);
    
    // إضافة مستمعي الأحداث لأزرار التنقل
    document.getElementById('prevMonth').addEventListener('click', function() {
        const monthText = document.getElementById('currentMonth').textContent;
        const [month, year] = monthText.split(' ');
        let newMonth = getMonthNumber(month) - 1;
        let newYear = parseInt(year);
        
        if (newMonth < 0) {
            newMonth = 11;
            newYear--;
        }
        
        renderCalendar(newMonth, newYear);
    });
    
    document.getElementById('nextMonth').addEventListener('click', function() {
        const monthText = document.getElementById('currentMonth').textContent;
        const [month, year] = monthText.split(' ');
        let newMonth = getMonthNumber(month) + 1;
        let newYear = parseInt(year);
        
        if (newMonth > 11) {
            newMonth = 0;
            newYear++;
        }
        
        renderCalendar(newMonth, newYear);
    });
}

// عرض التقويم
function renderCalendar(month, year) {
    const calendarContainer = document.getElementById('calendar');
    if (!calendarContainer) return;
    
    const monthNames = {
        ar: ['يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
        en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    };
    
    const dayNames = {
        ar: ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'],
        en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
    };
    
    // تحديد اللغة الحالية
    const lang = document.documentElement.lang || 'ar';
    
    // تحديث عنوان الشهر
    document.getElementById('currentMonth').textContent = `${monthNames[lang][month]} ${year}`;
    
    // الحصول على عدد أيام الشهر
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    // الحصول على اليوم الأول من الشهر
    const firstDay = new Date(year, month, 1).getDay();
    
    // إنشاء مصفوفة الأيام
    let days = [];
    
    // إضافة أيام الشهر السابق
    for (let i = 0; i < firstDay; i++) {
        days.push({
            day: new Date(year, month, -i).getDate(),
            isCurrentMonth: false,
            hasAppointment: false
        });
    }
    days.reverse();
    
    // إضافة أيام الشهر الحالي
    for (let i = 1; i <= daysInMonth; i++) {
        // تحقق من وجود مواعيد في هذا اليوم (يمكن استبداله بمنطق حقيقي)
        const hasAppointment = Math.random() > 0.7;
        
        days.push({
            day: i,
            isCurrentMonth: true,
            hasAppointment: hasAppointment
        });
    }
    
    // إضافة أيام الشهر التالي لإكمال الأسبوع الأخير
    const remainingDays = 7 - (days.length % 7);
    if (remainingDays < 7) {
        for (let i = 1; i <= remainingDays; i++) {
            days.push({
                day: i,
                isCurrentMonth: false,
                hasAppointment: false
            });
        }
    }
    
    // إنشاء HTML للتقويم
    let calendarHTML = '';
    
    // إضافة أسماء الأيام
    for (let i = 0; i < 7; i++) {
        calendarHTML += `<div class="calendar-day-name">${dayNames[lang][i]}</div>`;
    }
    
    // إضافة الأيام
    days.forEach(day => {
        let dayClass = 'calendar-day';
        if (!day.isCurrentMonth) {
            dayClass += ' other-month';
        }
        if (day.hasAppointment) {
            dayClass += ' has-appointment';
        }
        
        calendarHTML += `
            <div class="${dayClass}" data-day="${day.day}" data-month="${month}" data-year="${year}">
                ${day.day}
                ${day.hasAppointment ? '<span class="appointment-indicator"></span>' : ''}
            </div>
        `;
    });
    
    // تحديث التقويم
    calendarContainer.innerHTML = calendarHTML;
    
    // إضافة مستمعي الأحداث للأيام
    document.querySelectorAll('.calendar-day').forEach(dayElement => {
        dayElement.addEventListener('click', function() {
            if (this.classList.contains('has-appointment')) {
                showDayAppointments(this.dataset.day, this.dataset.month, this.dataset.year);
            }
        });
    });
}

// الحصول على رقم الشهر من اسمه
function getMonthNumber(monthName) {
    const monthNames = {
        'يناير': 0, 'فبراير': 1, 'مارس': 2, 'إبريل': 3, 'مايو': 4, 'يونيو': 5,
        'يوليو': 6, 'أغسطس': 7, 'سبتمبر': 8, 'أكتوبر': 9, 'نوفمبر': 10, 'ديسمبر': 11,
        'January': 0, 'February': 1, 'March': 2, 'April': 3, 'May': 4, 'June': 5,
        'July': 6, 'August': 7, 'September': 8, 'October': 9, 'November': 10, 'December': 11
    };
    
    return monthNames[monthName] || 0;
}

// عرض مواعيد اليوم
function showDayAppointments(day, month, year) {
    const modal = document.getElementById('dayAppointmentsModal');
    const appointmentsList = document.getElementById('dayAppointmentsList');
    
    // بيانات تجريبية للمواعيد
    const appointments = [
        { time: '09:00', patient: 'أحمد محمد', doctor: 'د. سارة أحمد', type: 'استشارة' },
        { time: '10:30', patient: 'فاطمة علي', doctor: 'د. خالد محمود', type: 'متابعة' },
        { time: '11:45', patient: 'محمد عبدالله', doctor: 'د. نورا سعيد', type: 'فحص روتيني' }
    ];
    
    // إنشاء HTML للمواعيد
    let appointmentsHTML = `<h4>مواعيد يوم ${day}/${parseInt(month) + 1}/${year}</h4>`;
    
    if (appointments.length === 0) {
        appointmentsHTML += '<p>لا توجد مواعيد في هذا اليوم.</p>';
    } else {
        appointmentsHTML += '<div class="day-appointments-list">';
        appointments.forEach(appointment => {
            appointmentsHTML += `
                <div class="day-appointment-item">
                    <div class="appointment-time">${appointment.time}</div>
                    <div class="appointment-details">
                        <h5>${appointment.patient}</h5>
                        <p>${appointment.doctor} - ${appointment.type}</p>
                    </div>
                </div>
            `;
        });
        appointmentsHTML += '</div>';
    }
    
    // تحديث المحتوى وعرض النافذة المنبثقة
    appointmentsList.innerHTML = appointmentsHTML;
    openModal(modal);
}

// تهيئة الرسوم البيانية
function initCharts() {
    // التحقق من وجود عناصر الرسوم البيانية
    const chartElements = document.querySelectorAll('[data-chart]');
    if (chartElements.length === 0) return;
    
    // تحميل مكتبة Chart.js إذا لم تكن موجودة
    if (typeof Chart === 'undefined') {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
        script.onload = createCharts;
        document.head.appendChild(script);
    } else {
        createCharts();
    }
}

// إنشاء الرسوم البيانية
function createCharts() {
    // رسم بياني لتوزيع المرضى حسب الجنس
    const patientsChartElement = document.querySelector('[data-chart="patients"]');
    if (patientsChartElement) {
        const ctx = document.createElement('canvas');
        patientsChartElement.appendChild(ctx);
        
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['ذكور', 'إناث'],
                datasets: [{
                    data: [65, 35],
                    backgroundColor: ['#4CAF50', '#2196F3'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    // رسم بياني لعدد الزيارات الشهرية
    const visitsChartElement = document.querySelector('[data-chart="visits"]');
    if (visitsChartElement) {
        const ctx = document.createElement('canvas');
        visitsChartElement.appendChild(ctx);
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو'],
                datasets: [{
                    label: 'عدد الزيارات',
                    data: [65, 59, 80, 81, 56, 55],
                    backgroundColor: '#4CAF50',
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
}

// تهيئة النوافذ المنبثقة
function initModals() {
    // إضافة مستمعي الأحداث لأزرار فتح النوافذ المنبثقة
    document.querySelectorAll('[data-modal]').forEach(button => {
        button.addEventListener('click', function() {
            const modalId = this.dataset.modal;
            const modal = document.getElementById(modalId);
            if (modal) {
                openModal(modal);
            }
        });
    });
    
    // إضافة مستمعي الأحداث لأزرار إغلاق النوافذ المنبثقة
    document.querySelectorAll('.close-button').forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.modal');
            closeModal(modal);
        });
    });
    
    // إضافة مستمعي الأحداث لأزرار الإجراءات في جدول المواعيد
    document.querySelectorAll('.table-actions button').forEach(button => {
        button.addEventListener('click', function() {
            const action = this.dataset.action;
            const id = this.dataset.id;
            
            if (action === 'view') {
                showAppointmentDetails(id);
            } else if (action === 'edit') {
                editAppointment(id);
            } else if (action === 'delete') {
                confirmDeleteAppointment(id);
            }
        });
    });
}

// فتح نافذة منبثقة
function openModal(modal) {
    if (!modal) return;
    modal.style.display = 'block';
    
    // إضافة مستمع حدث للنقر خارج النافذة
    modal.addEventListener('click', function(event) {
        if (event.target === this) {
            closeModal(this);
        }
    });
}

// إغلاق نافذة منبثقة
function closeModal(modal) {
    if (!modal) return;
    modal.style.display = 'none';
}

// عرض تفاصيل الموعد
function showAppointmentDetails(id) {
    const modal = document.getElementById('appointmentsTableViewModal');
    if (!modal) return;
    
    // بيانات تجريبية للموعد
    const appointment = {
        patient: 'أحمد محمد',
        doctor: 'د. سارة أحمد',
        date: '22 مايو 2025',
        time: '10:30 ص',
        type: 'استشارة',
        status: 'مؤكد',
        notes: 'مراجعة نتائج التحاليل السابقة'
    };
    
    // ملء البيانات في النافذة المنبثقة
    modal.querySelectorAll('[data-field]').forEach(field => {
        const fieldName = field.dataset.field;
        if (appointment[fieldName]) {
            field.textContent = appointment[fieldName];
        }
    });
    
    // عرض النافذة المنبثقة
    openModal(modal);
}

// تعديل الموعد
function editAppointment(id) {
    const modal = document.getElementById('appointmentsTableEditModal');
    if (!modal) return;
    
    // بيانات تجريبية للموعد
    const appointment = {
        patient: '1',
        doctor: '1',
        date: '2025-05-22',
        time: '10:30',
        type: 'consultation',
        status: 'confirmed',
        notes: 'مراجعة نتائج التحاليل السابقة'
    };
    
    // ملء النموذج بالبيانات
    const form = document.getElementById('editAppointmentForm');
    if (form) {
        for (const field in appointment) {
            const input = form.elements[field];
            if (input) {
                input.value = appointment[field];
            }
        }
    }
    
    // عرض النافذة المنبثقة
    openModal(modal);
}

// تأكيد حذف الموعد
function confirmDeleteAppointment(id) {
    const modal = document.getElementById('appointmentsTableDeleteModal');
    if (!modal) return;
    
    // تعيين معرف الموعد لزر الحذف
    const deleteButton = modal.querySelector('.btn-danger');
    if (deleteButton) {
        deleteButton.setAttribute('data-id', id);
    }
    
    // عرض النافذة المنبثقة
    openModal(modal);
}

// حذف الموعد
function deleteAppointment(id) {
    // هنا يمكن إضافة كود لحذف الموعد من قاعدة البيانات
    
    // إغلاق النافذة المنبثقة
    closeModal(document.getElementById('appointmentsTableDeleteModal'));
    
    // عرض إشعار نجاح
    showToast('تم الحذف بنجاح', 'تم حذف الموعد بنجاح.', 'success');
}

// حفظ الموعد
function saveAppointment() {
    // هنا يمكن إضافة كود لحفظ الموعد في قاعدة البيانات
    
    // إغلاق النافذة المنبثقة
    closeModal(document.getElementById('appointmentsTableEditModal'));
    
    // عرض إشعار نجاح
    showToast('تم الحفظ بنجاح', 'تم حفظ الموعد بنجاح.', 'success');
}

// تهيئة جدول المرضى
function initPatientsTable() {
    // بيانات تجريبية للمرضى
    const patients = [
        { id: 1, name: 'أحمد محمد', email: 'ahmed@example.com', phone: '0123456789', gender: 'ذكر', lastVisit: '15 مايو 2025' },
        { id: 2, name: 'فاطمة علي', email: 'fatima@example.com', phone: '0123456788', gender: 'أنثى', lastVisit: '10 مايو 2025' },
        { id: 3, name: 'محمد عبدالله', email: 'mohamed@example.com', phone: '0123456787', gender: 'ذكر', lastVisit: '5 مايو 2025' },
        { id: 4, name: 'سمية حسن', email: 'somaya@example.com', phone: '0123456786', gender: 'أنثى', lastVisit: '1 مايو 2025' },
        { id: 5, name: 'خالد سعيد', email: 'khaled@example.com', phone: '0123456785', gender: 'ذكر', lastVisit: '25 إبريل 2025' }
    ];
    
    // ملء الجدول بالبيانات
    const tbody = document.querySelector('#patientsTable tbody');
    if (!tbody) return;
    
    let tableHTML = '';
    patients.forEach(patient => {
        tableHTML += `
            <tr>
                <td>${patient.name}</td>
                <td>${patient.email}</td>
                <td>${patient.phone}</td>
                <td>${patient.gender}</td>
                <td>${patient.lastVisit}</td>
                <td class="table-actions">
                    <button class="btn-view" data-id="${patient.id}" data-action="view"><i class="fas fa-eye"></i></button>
                    <button class="btn-edit" data-id="${patient.id}" data-action="edit"><i class="fas fa-edit"></i></button>
                    <button class="btn-delete" data-id="${patient.id}" data-action="delete"><i class="fas fa-trash-alt"></i></button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = tableHTML;
    
    // إضافة مستمعي الأحداث لأزرار الإجراءات
    document.querySelectorAll('#patientsTable .table-actions button').forEach(button => {
        button.addEventListener('click', function() {
            const action = this.dataset.action;
            const id = this.dataset.id;
            
            if (action === 'view') {
                showPatientDetails(id);
            } else if (action === 'edit') {
                editPatient(id);
            } else if (action === 'delete') {
                confirmDeletePatient(id);
            }
        });
    });
    
    // إضافة مستمع حدث لحقل البحث
    const searchInput = document.getElementById('patientSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            filterPatients();
        });
    }
    
    // إضافة مستمع حدث لقائمة التصفية
    const filterSelect = document.getElementById('patientFilter');
    if (filterSelect) {
        filterSelect.addEventListener('change', function() {
            filterPatients();
        });
    }
}

// تصفية المرضى
function filterPatients() {
    const searchInput = document.getElementById('patientSearch');
    const filterSelect = document.getElementById('patientFilter');
    const tbody = document.querySelector('#patientsTable tbody');
    
    if (!searchInput || !filterSelect || !tbody) return;
    
    const searchTerm = searchInput.value.toLowerCase();
    const filterValue = filterSelect.value;
    
    const rows = tbody.querySelectorAll('tr');
    rows.forEach(row => {
        const name = row.cells[0].textContent.toLowerCase();
        const email = row.cells[1].textContent.toLowerCase();
        const phone = row.cells[2].textContent;
        
        // تطبيق تصفية البحث
        const matchesSearch = name.includes(searchTerm) || email.includes(searchTerm) || phone.includes(searchTerm);
        
        // تطبيق تصفية الحالة
        let matchesFilter = true;
        if (filterValue !== 'all') {
            // هنا يمكن إضافة منطق التصفية حسب الحالة
            // على سبيل المثال، يمكن إضافة خاصية للمرضى تحدد ما إذا كانوا نشطين أم لا
        }
        
        // عرض أو إخفاء الصف
        row.style.display = matchesSearch && matchesFilter ? '' : 'none';
    });
}

// عرض تفاصيل المريض
function showPatientDetails(id) {
    const modal = document.getElementById('patientsTableViewModal');
    if (!modal) return;
    
    // بيانات تجريبية للمريض
    const patient = {
        firstName: 'أحمد',
        lastName: 'محمد',
        fullName: 'أحمد محمد',
        email: 'ahmed@example.com',
        phone: '0123456789',
        dob: '15 يناير 1985',
        gender: 'ذكر',
        address: 'شارع 123، المدينة',
        medicalHistory: 'ضغط الدم المرتفع، السكري من النوع الثاني',
        insuranceInfo: 'شركة التأمين الصحي، رقم البوليصة: 123456',
        emergencyContact: 'محمد أحمد (الأخ) - 0123456780',
        lastVisit: '15 مايو 2025'
    };
    
    // ملء البيانات في النافذة المنبثقة
    modal.querySelectorAll('[data-field]').forEach(field => {
        const fieldName = field.dataset.field;
        if (patient[fieldName]) {
            field.textContent = patient[fieldName];
        }
    });
    
    // عرض النافذة المنبثقة
    openModal(modal);
}

// تعديل بيانات المريض
function editPatient(id) {
    const modal = document.getElementById('patientsTableEditModal');
    if (!modal) return;
    
    // بيانات تجريبية للمريض
    const patient = {
        firstName: 'أحمد',
        lastName: 'محمد',
        email: 'ahmed@example.com',
        phone: '0123456789',
        dob: '1985-01-15',
        gender: 'male',
        address: 'شارع 123، المدينة',
        medicalHistory: 'ضغط الدم المرتفع، السكري من النوع الثاني',
        insuranceInfo: 'شركة التأمين الصحي، رقم البوليصة: 123456',
        emergencyContact: 'محمد أحمد (الأخ) - 0123456780'
    };
    
    // ملء النموذج بالبيانات
    const form = document.getElementById('editPatientForm');
    if (form) {
        for (const field in patient) {
            const input = form.elements[field];
            if (input) {
                input.value = patient[field];
            }
        }
    }
    
    // عرض النافذة المنبثقة
    openModal(modal);
}

// تأكيد حذف المريض
function confirmDeletePatient(id) {
    const modal = document.getElementById('patientsTableDeleteModal');
    if (!modal) return;
    
    // تعيين معرف المريض لزر الحذف
    const deleteButton = modal.querySelector('.btn-danger');
    if (deleteButton) {
        deleteButton.setAttribute('data-id', id);
    }
    
    // عرض النافذة المنبثقة
    openModal(modal);
}

// حذف المريض
function deletePatient(id) {
    // هنا يمكن إضافة كود لحذف المريض من قاعدة البيانات
    
    // إغلاق النافذة المنبثقة
    closeModal(document.getElementById('patientsTableDeleteModal'));
    
    // عرض إشعار نجاح
    showToast('تم الحذف بنجاح', 'تم حذف المريض بنجاح.', 'success');
    
    // إزالة الصف من الجدول
    const row = document.querySelector(`#patientsTable tbody tr button[data-id="${id}"]`).closest('tr');
    if (row) {
        row.remove();
    }
}

// حفظ المريض
function savePatient() {
    // هنا يمكن إضافة كود لحفظ المريض في قاعدة البيانات
    
    // إغلاق النافذة المنبثقة
    closeModal(document.getElementById('addPatientModal'));
    
    // عرض إشعار نجاح
    showToast('تم الحفظ بنجاح', 'تم إضافة المريض بنجاح.', 'success');
    
    // إعادة تحميل جدول المرضى
    initPatientsTable();
}

// تحديث بيانات المريض
function updatePatient() {
    // هنا يمكن إضافة كود لتحديث بيانات المريض في قاعدة البيانات
    
    // إغلاق النافذة المنبثقة
    closeModal(document.getElementById('patientsTableEditModal'));
    
    // عرض إشعار نجاح
    showToast('تم التحديث بنجاح', 'تم تحديث بيانات المريض بنجاح.', 'success');
    
    // إعادة تحميل جدول المرضى
    initPatientsTable();
}

// عرض إشعار منبثق
function showToast(title, message, type) {
    const toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'times' : type === 'warning' ? 'exclamation' : 'info'}"></i>
        </div>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
        <button class="toast-close">&times;</button>
    `;
    
    toastContainer.appendChild(toast);
    
    // إضافة مستمع حدث لزر الإغلاق
    toast.querySelector('.toast-close').addEventListener('click', function() {
        toast.remove();
    });
    
    // إزالة الإشعار تلقائياً بعد 5 ثوانٍ
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

// تهيئة قائمة المستخدم
function initUserMenu() {
    const userIcon = document.querySelector('.user-icon');
    const userDropdown = document.querySelector('.user-dropdown');
    
    if (!userIcon || !userDropdown) return;
    
    userIcon.addEventListener('click', function() {
        userDropdown.style.display = userDropdown.style.display === 'block' ? 'none' : 'block';
    });
    
    // إخفاء القائمة عند النقر خارجها
    document.addEventListener('click', function(event) {
        if (!userIcon.contains(event.target) && !userDropdown.contains(event.target)) {
            userDropdown.style.display = 'none';
        }
    });
}

// تهيئة زر تبديل اللغة
function initLanguageSwitch() {
    const languageSwitch = document.querySelector('.language-switch');
    if (!languageSwitch) return;
    
    languageSwitch.addEventListener('click', function() {
        toggleLanguage();
    });
}

// تبديل اللغة
function toggleLanguage() {
    const html = document.documentElement;
    const langText = document.querySelector('.lang-text');
    
    if (html.lang === 'ar') {
        html.lang = 'en';
        html.dir = 'ltr';
        if (langText) langText.textContent = 'العربية';
    } else {
        html.lang = 'ar';
        html.dir = 'rtl';
        if (langText) langText.textContent = 'English';
    }
    
    // إعادة تهيئة التقويم إذا كان موجوداً
    if (document.getElementById('calendar')) {
        const monthText = document.getElementById('currentMonth').textContent;
        const [month, year] = monthText.split(' ');
        renderCalendar(getMonthNumber(month), parseInt(year));
    }
}
