from datetime import datetime
from src.models import db
from src.models.user import User

class Patient(db.Model):
    """نموذج المرضى في النظام"""
    __tablename__ = 'patients'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    gender = db.Column(db.String(10), nullable=False)  # ذكر، أنثى
    date_of_birth = db.Column(db.Date, nullable=False)
    blood_type = db.Column(db.String(5), nullable=True)  # A+, B-, AB+, O- إلخ
    address = db.Column(db.String(255), nullable=True)
    address_ar = db.Column(db.String(255), nullable=True)  # العنوان باللغة العربية
    emergency_contact_name = db.Column(db.String(100), nullable=True)
    emergency_contact_name_ar = db.Column(db.String(100), nullable=True)  # اسم جهة الاتصال في حالات الطوارئ بالعربية
    emergency_contact_phone = db.Column(db.String(20), nullable=True)
    emergency_contact_relation = db.Column(db.String(50), nullable=True)
    emergency_contact_relation_ar = db.Column(db.String(50), nullable=True)  # صلة القرابة بالعربية
    medical_history = db.Column(db.Text, nullable=True)  # التاريخ الطبي
    medical_history_ar = db.Column(db.Text, nullable=True)  # التاريخ الطبي بالعربية
    allergies = db.Column(db.Text, nullable=True)  # الحساسية
    allergies_ar = db.Column(db.Text, nullable=True)  # الحساسية بالعربية
    chronic_diseases = db.Column(db.Text, nullable=True)  # الأمراض المزمنة
    chronic_diseases_ar = db.Column(db.Text, nullable=True)  # الأمراض المزمنة بالعربية
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    user = db.relationship('User', back_populates='patient')
    appointments = db.relationship('Appointment', back_populates='patient')
    medical_records = db.relationship('MedicalRecord', back_populates='patient')
    
    def __repr__(self):
        return f'<Patient {self.user.first_name} {self.user.last_name}>'
