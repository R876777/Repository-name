from datetime import datetime
from src.models import db
from src.models.patient import Patient
from src.models.doctor import Doctor

class Appointment(db.Model):
    """نموذج المواعيد في النظام"""
    __tablename__ = 'appointments'
    
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'), nullable=False)
    appointment_date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='pending')  # pending, confirmed, cancelled, completed
    status_ar = db.Column(db.String(20), nullable=True)  # حالة الموعد بالعربية
    appointment_type = db.Column(db.String(50), nullable=False, default='regular')  # regular, follow-up, emergency
    appointment_type_ar = db.Column(db.String(50), nullable=True)  # نوع الموعد بالعربية
    reason = db.Column(db.Text, nullable=True)  # سبب الزيارة
    reason_ar = db.Column(db.Text, nullable=True)  # سبب الزيارة بالعربية
    notes = db.Column(db.Text, nullable=True)  # ملاحظات إضافية
    notes_ar = db.Column(db.Text, nullable=True)  # ملاحظات إضافية بالعربية
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    patient = db.relationship('Patient', back_populates='appointments')
    doctor = db.relationship('Doctor', back_populates='appointments')
    visit = db.relationship('Visit', uselist=False, back_populates='appointment')
    
    def __repr__(self):
        return f'<Appointment {self.id}: {self.patient.user.first_name} with Dr. {self.doctor.user.last_name}>'
