from datetime import datetime
from src.models import db
from werkzeug.security import generate_password_hash, check_password_hash

# جدول العلاقة بين المستخدمين والأدوار
user_roles = db.Table('user_roles',
    db.Column('user_id', db.Integer, db.ForeignKey('users.id'), primary_key=True),
    db.Column('role_id', db.Integer, db.ForeignKey('roles.id'), primary_key=True)
)

class Role(db.Model):
    """نموذج الأدوار والصلاحيات في النظام"""
    __tablename__ = 'roles'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    name_ar = db.Column(db.String(100), nullable=True)  # الاسم باللغة العربية
    description = db.Column(db.String(255), nullable=True)
    description_ar = db.Column(db.String(255), nullable=True)  # الوصف باللغة العربية
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقة مع المستخدمين
    users = db.relationship('User', secondary=user_roles, back_populates='roles')
    
    def __repr__(self):
        return f'<Role {self.name}>'

class User(db.Model):
    """نموذج المستخدمين في النظام"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    first_name_ar = db.Column(db.String(50), nullable=True)  # الاسم الأول باللغة العربية
    last_name = db.Column(db.String(50), nullable=False)
    last_name_ar = db.Column(db.String(50), nullable=True)  # الاسم الأخير باللغة العربية
    phone = db.Column(db.String(20), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    language_preference = db.Column(db.String(10), default='ar')  # ar للعربية، en للإنجليزية
    last_login = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    roles = db.relationship('Role', secondary=user_roles, back_populates='users')
    patient = db.relationship('Patient', uselist=False, back_populates='user')
    doctor = db.relationship('Doctor', uselist=False, back_populates='user')
    notifications = db.relationship('Notification', back_populates='user')
    
    @property
    def password(self):
        raise AttributeError('كلمة المرور غير قابلة للقراءة')
    
    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def has_role(self, role_name):
        """التحقق مما إذا كان المستخدم يملك دوراً محدداً"""
        return any(role.name == role_name for role in self.roles)
    
    def __repr__(self):
        return f'<User {self.username}>'
