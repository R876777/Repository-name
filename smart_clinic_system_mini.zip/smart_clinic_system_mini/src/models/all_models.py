from src.models import db
from src.models.user import User, Role
from src.models.patient import Patient
from src.models.doctor import Doctor
from src.models.appointment import Appointment
from src.models.visit import Visit
from src.models.prescription import Prescription, PrescriptionItem
from src.models.invoice import Invoice, InvoiceItem
from src.models.notification import Notification
from src.models.medical_record import MedicalRecord

# تصدير جميع النماذج لتسهيل الاستيراد
__all__ = [
    'db',
    'User',
    'Role',
    'Patient',
    'Doctor',
    'Appointment',
    'Visit',
    'Prescription',
    'PrescriptionItem',
    'Invoice',
    'InvoiceItem',
    'Notification',
    'MedicalRecord'
]
