from datetime import datetime
from src.models import db
from src.models.visit import Visit

class Invoice(db.Model):
    """نموذج الفواتير في النظام"""
    __tablename__ = 'invoices'
    
    id = db.Column(db.Integer, primary_key=True)
    visit_id = db.Column(db.Integer, db.ForeignKey('visits.id'), nullable=False)
    invoice_number = db.Column(db.String(50), nullable=False, unique=True)
    issue_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    due_date = db.Column(db.DateTime, nullable=True)
    total_amount = db.Column(db.Float, nullable=False, default=0.0)
    paid_amount = db.Column(db.Float, nullable=False, default=0.0)
    status = db.Column(db.String(20), nullable=False, default='pending')  # pending, paid, partially_paid, cancelled
    status_ar = db.Column(db.String(20), nullable=True)  # حالة الفاتورة بالعربية
    payment_method = db.Column(db.String(50), nullable=True)
    payment_method_ar = db.Column(db.String(50), nullable=True)  # طريقة الدفع بالعربية
    notes = db.Column(db.Text, nullable=True)
    notes_ar = db.Column(db.Text, nullable=True)  # ملاحظات بالعربية
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    visit = db.relationship('Visit', back_populates='invoices')
    invoice_items = db.relationship('InvoiceItem', back_populates='invoice', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Invoice {self.invoice_number}>'

class InvoiceItem(db.Model):
    """نموذج عناصر الفاتورة في النظام"""
    __tablename__ = 'invoice_items'
    
    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoices.id'), nullable=False)
    description = db.Column(db.String(255), nullable=False)
    description_ar = db.Column(db.String(255), nullable=True)  # وصف العنصر بالعربية
    quantity = db.Column(db.Integer, nullable=False, default=1)
    unit_price = db.Column(db.Float, nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    invoice = db.relationship('Invoice', back_populates='invoice_items')
    
    def __repr__(self):
        return f'<InvoiceItem {self.id}: {self.description}>'
