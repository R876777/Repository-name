from datetime import datetime
from src.models import db
from src.models.user import User

class Doctor(db.Model):
    """نموذج الأطباء في النظام"""
    __tablename__ = 'doctors'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    specialization = db.Column(db.String(100), nullable=False)
    specialization_ar = db.Column(db.String(100), nullable=True)  # التخصص باللغة العربية
    qualification = db.Column(db.String(255), nullable=False)
    qualification_ar = db.Column(db.String(255), nullable=True)  # المؤهلات باللغة العربية
    license_number = db.Column(db.String(50), nullable=False, unique=True)
    years_of_experience = db.Column(db.Integer, nullable=True)
    bio = db.Column(db.Text, nullable=True)
    bio_ar = db.Column(db.Text, nullable=True)  # السيرة الذاتية باللغة العربية
    consultation_fee = db.Column(db.Float, nullable=False, default=0.0)
    available_days = db.Column(db.String(100), nullable=True)  # أيام العمل مفصولة بفواصل
    available_days_ar = db.Column(db.String(100), nullable=True)  # أيام العمل باللغة العربية
    start_time = db.Column(db.Time, nullable=True)  # وقت بدء العمل
    end_time = db.Column(db.Time, nullable=True)  # وقت انتهاء العمل
    is_available = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    user = db.relationship('User', back_populates='doctor')
    appointments = db.relationship('Appointment', back_populates='doctor')
    prescriptions = db.relationship('Prescription', back_populates='doctor')
    
    def __repr__(self):
        return f'<Doctor {self.user.first_name} {self.user.last_name}>'
