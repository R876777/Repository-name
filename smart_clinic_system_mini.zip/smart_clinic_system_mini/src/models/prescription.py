from datetime import datetime
from src.models import db
from src.models.doctor import Doctor
from src.models.visit import Visit

class Prescription(db.Model):
    """نموذج الوصفات الطبية في النظام"""
    __tablename__ = 'prescriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    visit_id = db.Column(db.Integer, db.ForeignKey('visits.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'), nullable=False)
    prescription_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    status = db.Column(db.String(20), nullable=False, default='active')  # active, completed, cancelled
    status_ar = db.Column(db.String(20), nullable=True)  # حالة الوصفة بالعربية
    notes = db.Column(db.Text, nullable=True)  # ملاحظات إضافية
    notes_ar = db.Column(db.Text, nullable=True)  # ملاحظات إضافية بالعربية
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    visit = db.relationship('Visit', back_populates='prescriptions')
    doctor = db.relationship('Doctor', back_populates='prescriptions')
    prescription_items = db.relationship('PrescriptionItem', back_populates='prescription', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Prescription {self.id} for Visit {self.visit_id}>'

class PrescriptionItem(db.Model):
    """نموذج عناصر الوصفة الطبية في النظام"""
    __tablename__ = 'prescription_items'
    
    id = db.Column(db.Integer, primary_key=True)
    prescription_id = db.Column(db.Integer, db.ForeignKey('prescriptions.id'), nullable=False)
    medication_name = db.Column(db.String(100), nullable=False)
    medication_name_ar = db.Column(db.String(100), nullable=True)  # اسم الدواء بالعربية
    dosage = db.Column(db.String(50), nullable=False)
    dosage_ar = db.Column(db.String(50), nullable=True)  # الجرعة بالعربية
    frequency = db.Column(db.String(50), nullable=False)
    frequency_ar = db.Column(db.String(50), nullable=True)  # التكرار بالعربية
    duration = db.Column(db.String(50), nullable=False)
    duration_ar = db.Column(db.String(50), nullable=True)  # المدة بالعربية
    instructions = db.Column(db.Text, nullable=True)
    instructions_ar = db.Column(db.Text, nullable=True)  # التعليمات بالعربية
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    prescription = db.relationship('Prescription', back_populates='prescription_items')
    
    def __repr__(self):
        return f'<PrescriptionItem {self.id}: {self.medication_name}>'
