from datetime import datetime
from src.models import db
from src.models.patient import Patient
from src.models.visit import Visit

class MedicalRecord(db.Model):
    """نموذج التقارير الطبية في النظام"""
    __tablename__ = 'medical_records'
    
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'), nullable=False)
    visit_id = db.Column(db.Integer, db.ForeignKey('visits.id'), nullable=True)
    record_type = db.Column(db.String(50), nullable=False)  # lab_result, radiology, surgery, general
    record_type_ar = db.Column(db.String(50), nullable=True)  # نوع التقرير بالعربية
    title = db.Column(db.String(100), nullable=False)
    title_ar = db.Column(db.String(100), nullable=True)  # عنوان التقرير بالعربية
    content = db.Column(db.Text, nullable=False)
    content_ar = db.Column(db.Text, nullable=True)  # محتوى التقرير بالعربية
    file_path = db.Column(db.String(255), nullable=True)  # مسار الملف المرفق (إن وجد)
    is_confidential = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    patient = db.relationship('Patient', back_populates='medical_records')
    visit = db.relationship('Visit', back_populates='medical_records')
    
    def __repr__(self):
        return f'<MedicalRecord {self.id}: {self.title}>'
