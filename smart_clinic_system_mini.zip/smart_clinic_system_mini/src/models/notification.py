from datetime import datetime
from src.models import db
from src.models.user import User
from src.models.patient import Patient
from src.models.visit import Visit

class Notification(db.Model):
    """نموذج الإشعارات في النظام"""
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    title_ar = db.Column(db.String(100), nullable=True)  # عنوان الإشعار بالعربية
    content = db.Column(db.Text, nullable=False)
    content_ar = db.Column(db.Text, nullable=True)  # محتوى الإشعار بالعربية
    notification_type = db.Column(db.String(50), nullable=False)  # appointment, prescription, invoice, system
    notification_type_ar = db.Column(db.String(50), nullable=True)  # نوع الإشعار بالعربية
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    user = db.relationship('User', back_populates='notifications')
    
    def __repr__(self):
        return f'<Notification {self.id}: {self.title}>'
