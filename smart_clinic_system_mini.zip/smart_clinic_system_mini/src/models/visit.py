from datetime import datetime
from src.models import db
from src.models.appointment import Appointment
from src.models.patient import Patient

class Visit(db.Model):
    """نموذج الزيارات الطبية في النظام"""
    __tablename__ = 'visits'
    
    id = db.Column(db.Integer, primary_key=True)
    appointment_id = db.Column(db.Integer, db.ForeignKey('appointments.id'), nullable=False)
    visit_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    chief_complaint = db.Column(db.Text, nullable=True)  # الشكوى الرئيسية
    chief_complaint_ar = db.Column(db.Text, nullable=True)  # الشكوى الرئيسية بالعربية
    symptoms = db.Column(db.Text, nullable=True)  # الأعراض
    symptoms_ar = db.Column(db.Text, nullable=True)  # الأعراض بالعربية
    diagnosis = db.Column(db.Text, nullable=True)  # التشخيص
    diagnosis_ar = db.Column(db.Text, nullable=True)  # التشخيص بالعربية
    treatment_plan = db.Column(db.Text, nullable=True)  # خطة العلاج
    treatment_plan_ar = db.Column(db.Text, nullable=True)  # خطة العلاج بالعربية
    notes = db.Column(db.Text, nullable=True)  # ملاحظات إضافية
    notes_ar = db.Column(db.Text, nullable=True)  # ملاحظات إضافية بالعربية
    
    # القياسات الحيوية
    temperature = db.Column(db.Float, nullable=True)  # درجة الحرارة
    blood_pressure = db.Column(db.String(20), nullable=True)  # ضغط الدم
    heart_rate = db.Column(db.Integer, nullable=True)  # معدل ضربات القلب
    respiratory_rate = db.Column(db.Integer, nullable=True)  # معدل التنفس
    weight = db.Column(db.Float, nullable=True)  # الوزن
    height = db.Column(db.Float, nullable=True)  # الطول
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات مع الجداول الأخرى
    appointment = db.relationship('Appointment', back_populates='visit')
    prescriptions = db.relationship('Prescription', back_populates='visit')
    medical_records = db.relationship('MedicalRecord', back_populates='visit')
    invoices = db.relationship('Invoice', back_populates='visit')
    
    def __repr__(self):
        return f'<Visit {self.id} for Appointment {self.appointment_id}>'
