from flask import Blueprint, request, jsonify
from src.models.all_models import db, MedicalRecord, Patient
from src.routes.auth import token_required, role_required

medical_record_bp = Blueprint('medical_record', __name__)

# الحصول على قائمة التقارير الطبية
@medical_record_bp.route('/', methods=['GET'])
@token_required
def get_medical_records(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # تصفية حسب المريض
    patient_id = request.args.get('patient_id', type=int)
    
    # تصفية حسب نوع التقرير
    record_type = request.args.get('record_type')
    
    query = MedicalRecord.query
    
    # تطبيق التصفية حسب الصلاحيات
    if any(role.name in ['admin', 'doctor', 'nurse'] for role in current_user.roles):
        # المدير والطبيب والممرض يمكنهم رؤية جميع التقارير (مع مراعاة التصفية)
        pass
    else:
        # المريض يرى تقاريره فقط
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        if patient:
            query = query.filter_by(patient_id=patient.id)
        else:
            return jsonify({
                'message': 'لم يتم العثور على بيانات المريض!',
                'message_en': 'Patient data not found!'
            }), 404
    
    # تطبيق التصفية حسب المعايير
    if patient_id:
        query = query.filter_by(patient_id=patient_id)
    if record_type:
        query = query.filter_by(record_type=record_type)
    
    # استبعاد التقارير السرية للمرضى
    if not any(role.name in ['admin', 'doctor', 'nurse'] for role in current_user.roles):
        query = query.filter_by(is_confidential=False)
    
    # ترتيب التقارير حسب التاريخ (الأحدث أولاً)
    query = query.order_by(MedicalRecord.created_at.desc())
    
    records = query.paginate(page=page, per_page=per_page, error_out=False)
    
    records_list = []
    for record in records.items:
        records_list.append({
            'id': record.id,
            'patient_id': record.patient_id,
            'patient_name': f"{record.patient.user.first_name} {record.patient.user.last_name}",
            'patient_name_ar': f"{record.patient.user.first_name_ar or ''} {record.patient.user.last_name_ar or ''}",
            'visit_id': record.visit_id,
            'record_type': record.record_type,
            'record_type_ar': record.record_type_ar,
            'title': record.title,
            'title_ar': record.title_ar,
            'is_confidential': record.is_confidential,
            'created_at': record.created_at.isoformat()
        })
    
    return jsonify({
        'medical_records': records_list,
        'total': records.total,
        'pages': records.pages,
        'current_page': records.page
    }), 200

# الحصول على تقرير طبي محدد بواسطة المعرف
@medical_record_bp.route('/<int:record_id>', methods=['GET'])
@token_required
def get_medical_record(current_user, record_id):
    record = MedicalRecord.query.get_or_404(record_id)
    
    # التحقق من الصلاحيات
    if not any(role.name in ['admin', 'doctor', 'nurse'] for role in current_user.roles):
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        if not patient or record.patient_id != patient.id or record.is_confidential:
            return jsonify({
                'message': 'غير مصرح لك بالوصول!',
                'message_en': 'Access denied!'
            }), 403
    
    return jsonify({
        'id': record.id,
        'patient_id': record.patient_id,
        'patient_name': f"{record.patient.user.first_name} {record.patient.user.last_name}",
        'patient_name_ar': f"{record.patient.user.first_name_ar or ''} {record.patient.user.last_name_ar or ''}",
        'visit_id': record.visit_id,
        'record_type': record.record_type,
        'record_type_ar': record.record_type_ar,
        'title': record.title,
        'title_ar': record.title_ar,
        'content': record.content,
        'content_ar': record.content_ar,
        'file_path': record.file_path,
        'is_confidential': record.is_confidential,
        'created_at': record.created_at.isoformat(),
        'updated_at': record.updated_at.isoformat()
    }), 200

# إنشاء تقرير طبي جديد
@medical_record_bp.route('/', methods=['POST'])
@token_required
@role_required(['admin', 'doctor', 'nurse'])
def create_medical_record(current_user):
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    required_fields = ['patient_id', 'record_type', 'title', 'content']
    for field in required_fields:
        if not data.get(field):
            return jsonify({
                'message': f'حقل {field} مطلوب!',
                'message_en': f'Field {field} is required!'
            }), 400
    
    # التحقق من وجود المريض
    patient = Patient.query.get(data.get('patient_id'))
    if not patient:
        return jsonify({
            'message': 'المريض غير موجود!',
            'message_en': 'Patient not found!'
        }), 404
    
    # إنشاء تقرير طبي جديد
    new_record = MedicalRecord(
        patient_id=data.get('patient_id'),
        visit_id=data.get('visit_id'),
        record_type=data.get('record_type'),
        record_type_ar=data.get('record_type_ar'),
        title=data.get('title'),
        title_ar=data.get('title_ar'),
        content=data.get('content'),
        content_ar=data.get('content_ar'),
        file_path=data.get('file_path'),
        is_confidential=data.get('is_confidential', False)
    )
    
    db.session.add(new_record)
    db.session.commit()
    
    return jsonify({
        'message': 'تم إنشاء التقرير الطبي بنجاح!',
        'message_en': 'Medical record created successfully!',
        'record_id': new_record.id
    }), 201

# تحديث تقرير طبي
@medical_record_bp.route('/<int:record_id>', methods=['PUT'])
@token_required
@role_required(['admin', 'doctor', 'nurse'])
def update_medical_record(current_user, record_id):
    record = MedicalRecord.query.get_or_404(record_id)
    data = request.get_json()
    
    # تحديث البيانات المسموح بها
    if data.get('record_type'):
        record.record_type = data.get('record_type')
    if data.get('record_type_ar'):
        record.record_type_ar = data.get('record_type_ar')
    if data.get('title'):
        record.title = data.get('title')
    if data.get('title_ar'):
        record.title_ar = data.get('title_ar')
    if data.get('content'):
        record.content = data.get('content')
    if data.get('content_ar'):
        record.content_ar = data.get('content_ar')
    if data.get('file_path'):
        record.file_path = data.get('file_path')
    if data.get('is_confidential') is not None:
        record.is_confidential = data.get('is_confidential')
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم تحديث التقرير الطبي بنجاح!',
        'message_en': 'Medical record updated successfully!'
    }), 200

# حذف تقرير طبي
@medical_record_bp.route('/<int:record_id>', methods=['DELETE'])
@token_required
@role_required(['admin', 'doctor'])
def delete_medical_record(current_user, record_id):
    record = MedicalRecord.query.get_or_404(record_id)
    
    db.session.delete(record)
    db.session.commit()
    
    return jsonify({
        'message': 'تم حذف التقرير الطبي بنجاح!',
        'message_en': 'Medical record deleted successfully!'
    }), 200

# الحصول على أنواع التقارير الطبية
@medical_record_bp.route('/record-types', methods=['GET'])
@token_required
def get_record_types(current_user):
    language = request.args.get('language', 'ar')  # ar للعربية، en للإنجليزية
    
    # استخراج جميع أنواع التقارير الفريدة
    if language == 'ar':
        record_types = db.session.query(MedicalRecord.record_type_ar).distinct().all()
        record_types = [t[0] for t in record_types if t[0]]
    else:
        record_types = db.session.query(MedicalRecord.record_type).distinct().all()
        record_types = [t[0] for t in record_types if t[0]]
    
    # إضافة الأنواع الافتراضية إذا كانت القائمة فارغة
    if not record_types:
        if language == 'ar':
            record_types = ['نتائج مخبرية', 'تقرير أشعة', 'تقرير جراحة', 'تقرير عام']
        else:
            record_types = ['lab_result', 'radiology', 'surgery', 'general']
    
    return jsonify({
        'record_types': record_types
    }), 200
