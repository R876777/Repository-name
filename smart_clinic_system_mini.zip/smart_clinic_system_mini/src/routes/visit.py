from flask import Blueprint, request, jsonify
from src.models.all_models import db, Visit, Appointment, MedicalRecord
from src.routes.auth import token_required, role_required

visit_bp = Blueprint('visit', __name__)

# الحصول على قائمة الزيارات
@visit_bp.route('/', methods=['GET'])
@token_required
def get_visits(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # تصفية حسب المريض أو الطبيب
    patient_id = request.args.get('patient_id', type=int)
    doctor_id = request.args.get('doctor_id', type=int)
    
    # تصفية حسب التاريخ
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    query = Visit.query.join(Appointment)
    
    # تطبيق التصفية حسب الصلاحيات
    if any(role.name == 'admin' for role in current_user.roles):
        # المدير يمكنه رؤية جميع الزيارات
        pass
    elif any(role.name == 'doctor' for role in current_user.roles):
        # الطبيب يرى زيارات مرضاه فقط
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        if doctor:
            query = query.filter(Appointment.doctor_id == doctor.id)
        else:
            return jsonify({
                'message': 'لم يتم العثور على بيانات الطبيب!',
                'message_en': 'Doctor data not found!'
            }), 404
    elif any(role.name == 'nurse' for role in current_user.roles):
        # الممرض يرى جميع الزيارات
        pass
    else:
        # المريض يرى زياراته فقط
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        if patient:
            query = query.filter(Appointment.patient_id == patient.id)
        else:
            return jsonify({
                'message': 'لم يتم العثور على بيانات المريض!',
                'message_en': 'Patient data not found!'
            }), 404
    
    # تطبيق التصفية حسب المعايير
    if patient_id:
        query = query.filter(Appointment.patient_id == patient_id)
    if doctor_id:
        query = query.filter(Appointment.doctor_id == doctor_id)
    if start_date:
        query = query.filter(Visit.visit_date >= start_date)
    if end_date:
        query = query.filter(Visit.visit_date <= end_date)
    
    # ترتيب الزيارات حسب التاريخ (الأحدث أولاً)
    query = query.order_by(Visit.visit_date.desc())
    
    visits = query.paginate(page=page, per_page=per_page, error_out=False)
    
    visits_list = []
    for visit in visits.items:
        appointment = visit.appointment
        visits_list.append({
            'id': visit.id,
            'appointment_id': visit.appointment_id,
            'patient_id': appointment.patient_id,
            'patient_name': f"{appointment.patient.user.first_name} {appointment.patient.user.last_name}",
            'patient_name_ar': f"{appointment.patient.user.first_name_ar or ''} {appointment.patient.user.last_name_ar or ''}",
            'doctor_id': appointment.doctor_id,
            'doctor_name': f"د. {appointment.doctor.user.first_name} {appointment.doctor.user.last_name}",
            'doctor_name_ar': f"د. {appointment.doctor.user.first_name_ar or ''} {appointment.doctor.user.last_name_ar or ''}",
            'visit_date': visit.visit_date.isoformat(),
            'diagnosis': visit.diagnosis,
            'created_at': visit.created_at.isoformat()
        })
    
    return jsonify({
        'visits': visits_list,
        'total': visits.total,
        'pages': visits.pages,
        'current_page': visits.page
    }), 200

# الحصول على زيارة محددة بواسطة المعرف
@visit_bp.route('/<int:visit_id>', methods=['GET'])
@token_required
def get_visit(current_user, visit_id):
    visit = Visit.query.get_or_404(visit_id)
    appointment = visit.appointment
    
    # التحقق من الصلاحيات
    if not any(role.name in ['admin', 'nurse'] for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        
        if (doctor and appointment.doctor_id != doctor.id) and (patient and appointment.patient_id != patient.id):
            return jsonify({
                'message': 'غير مصرح لك بالوصول!',
                'message_en': 'Access denied!'
            }), 403
    
    return jsonify({
        'id': visit.id,
        'appointment_id': visit.appointment_id,
        'patient_id': appointment.patient_id,
        'patient_name': f"{appointment.patient.user.first_name} {appointment.patient.user.last_name}",
        'patient_name_ar': f"{appointment.patient.user.first_name_ar or ''} {appointment.patient.user.last_name_ar or ''}",
        'doctor_id': appointment.doctor_id,
        'doctor_name': f"د. {appointment.doctor.user.first_name} {appointment.doctor.user.last_name}",
        'doctor_name_ar': f"د. {appointment.doctor.user.first_name_ar or ''} {appointment.doctor.user.last_name_ar or ''}",
        'visit_date': visit.visit_date.isoformat(),
        'chief_complaint': visit.chief_complaint,
        'chief_complaint_ar': visit.chief_complaint_ar,
        'symptoms': visit.symptoms,
        'symptoms_ar': visit.symptoms_ar,
        'diagnosis': visit.diagnosis,
        'diagnosis_ar': visit.diagnosis_ar,
        'treatment_plan': visit.treatment_plan,
        'treatment_plan_ar': visit.treatment_plan_ar,
        'notes': visit.notes,
        'notes_ar': visit.notes_ar,
        'temperature': visit.temperature,
        'blood_pressure': visit.blood_pressure,
        'heart_rate': visit.heart_rate,
        'respiratory_rate': visit.respiratory_rate,
        'weight': visit.weight,
        'height': visit.height,
        'created_at': visit.created_at.isoformat(),
        'updated_at': visit.updated_at.isoformat()
    }), 200

# إنشاء زيارة جديدة
@visit_bp.route('/', methods=['POST'])
@token_required
@role_required(['admin', 'doctor', 'nurse'])
def create_visit(current_user):
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data.get('appointment_id'):
        return jsonify({
            'message': 'معرف الموعد مطلوب!',
            'message_en': 'Appointment ID is required!'
        }), 400
    
    # التحقق من وجود الموعد
    appointment = Appointment.query.get(data.get('appointment_id'))
    if not appointment:
        return jsonify({
            'message': 'الموعد غير موجود!',
            'message_en': 'Appointment not found!'
        }), 404
    
    # التحقق من أن الموعد مؤكد
    if appointment.status != 'confirmed':
        return jsonify({
            'message': 'الموعد غير مؤكد!',
            'message_en': 'Appointment is not confirmed!'
        }), 400
    
    # التحقق من عدم وجود زيارة سابقة لهذا الموعد
    if Visit.query.filter_by(appointment_id=appointment.id).first():
        return jsonify({
            'message': 'توجد زيارة مسجلة بالفعل لهذا الموعد!',
            'message_en': 'A visit already exists for this appointment!'
        }), 400
    
    # إنشاء زيارة جديدة
    new_visit = Visit(
        appointment_id=data.get('appointment_id'),
        visit_date=data.get('visit_date'),
        chief_complaint=data.get('chief_complaint'),
        chief_complaint_ar=data.get('chief_complaint_ar'),
        symptoms=data.get('symptoms'),
        symptoms_ar=data.get('symptoms_ar'),
        diagnosis=data.get('diagnosis'),
        diagnosis_ar=data.get('diagnosis_ar'),
        treatment_plan=data.get('treatment_plan'),
        treatment_plan_ar=data.get('treatment_plan_ar'),
        notes=data.get('notes'),
        notes_ar=data.get('notes_ar'),
        temperature=data.get('temperature'),
        blood_pressure=data.get('blood_pressure'),
        heart_rate=data.get('heart_rate'),
        respiratory_rate=data.get('respiratory_rate'),
        weight=data.get('weight'),
        height=data.get('height')
    )
    
    # تحديث حالة الموعد إلى مكتمل
    appointment.status = 'completed'
    appointment.status_ar = 'مكتمل'
    
    db.session.add(new_visit)
    db.session.commit()
    
    return jsonify({
        'message': 'تم إنشاء الزيارة بنجاح!',
        'message_en': 'Visit created successfully!',
        'visit_id': new_visit.id
    }), 201

# تحديث زيارة
@visit_bp.route('/<int:visit_id>', methods=['PUT'])
@token_required
@role_required(['admin', 'doctor', 'nurse'])
def update_visit(current_user, visit_id):
    visit = Visit.query.get_or_404(visit_id)
    appointment = visit.appointment
    
    # التحقق من الصلاحيات للطبيب
    if any(role.name == 'doctor' for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        if doctor and appointment.doctor_id != doctor.id:
            return jsonify({
                'message': 'غير مصرح لك بالوصول!',
                'message_en': 'Access denied!'
            }), 403
    
    data = request.get_json()
    
    # تحديث البيانات المسموح بها
    if data.get('chief_complaint'):
        visit.chief_complaint = data.get('chief_complaint')
    if data.get('chief_complaint_ar'):
        visit.chief_complaint_ar = data.get('chief_complaint_ar')
    if data.get('symptoms'):
        visit.symptoms = data.get('symptoms')
    if data.get('symptoms_ar'):
        visit.symptoms_ar = data.get('symptoms_ar')
    if data.get('diagnosis'):
        visit.diagnosis = data.get('diagnosis')
    if data.get('diagnosis_ar'):
        visit.diagnosis_ar = data.get('diagnosis_ar')
    if data.get('treatment_plan'):
        visit.treatment_plan = data.get('treatment_plan')
    if data.get('treatment_plan_ar'):
        visit.treatment_plan_ar = data.get('treatment_plan_ar')
    if data.get('notes'):
        visit.notes = data.get('notes')
    if data.get('notes_ar'):
        visit.notes_ar = data.get('notes_ar')
    
    # تحديث القياسات الحيوية
    if data.get('temperature'):
        visit.temperature = data.get('temperature')
    if data.get('blood_pressure'):
        visit.blood_pressure = data.get('blood_pressure')
    if data.get('heart_rate'):
        visit.heart_rate = data.get('heart_rate')
    if data.get('respiratory_rate'):
        visit.respiratory_rate = data.get('respiratory_rate')
    if data.get('weight'):
        visit.weight = data.get('weight')
    if data.get('height'):
        visit.height = data.get('height')
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم تحديث الزيارة بنجاح!',
        'message_en': 'Visit updated successfully!'
    }), 200

# حذف زيارة (للمدير فقط)
@visit_bp.route('/<int:visit_id>', methods=['DELETE'])
@token_required
@role_required(['admin'])
def delete_visit(current_user, visit_id):
    visit = Visit.query.get_or_404(visit_id)
    
    db.session.delete(visit)
    db.session.commit()
    
    return jsonify({
        'message': 'تم حذف الزيارة بنجاح!',
        'message_en': 'Visit deleted successfully!'
    }), 200

# إضافة تقرير طبي للزيارة
@visit_bp.route('/<int:visit_id>/medical-records', methods=['POST'])
@token_required
@role_required(['admin', 'doctor'])
def add_medical_record(current_user, visit_id):
    visit = Visit.query.get_or_404(visit_id)
    appointment = visit.appointment
    
    # التحقق من الصلاحيات للطبيب
    if any(role.name == 'doctor' for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        if doctor and appointment.doctor_id != doctor.id:
            return jsonify({
                'message': 'غير مصرح لك بالوصول!',
                'message_en': 'Access denied!'
            }), 403
    
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    required_fields = ['record_type', 'title', 'content']
    for field in required_fields:
        if not data.get(field):
            return jsonify({
                'message': f'حقل {field} مطلوب!',
                'message_en': f'Field {field} is required!'
            }), 400
    
    # إنشاء تقرير طبي جديد
    new_record = MedicalRecord(
        patient_id=appointment.patient_id,
        visit_id=visit.id,
        record_type=data.get('record_type'),
        record_type_ar=data.get('record_type_ar'),
        title=data.get('title'),
        title_ar=data.get('title_ar'),
        content=data.get('content'),
        content_ar=data.get('content_ar'),
        file_path=data.get('file_path'),
        is_confidential=data.get('is_confidential', False)
    )
    
    db.session.add(new_record)
    db.session.commit()
    
    return jsonify({
        'message': 'تم إضافة التقرير الطبي بنجاح!',
        'message_en': 'Medical record added successfully!',
        'record_id': new_record.id
    }), 201

# الحصول على التقارير الطبية للزيارة
@visit_bp.route('/<int:visit_id>/medical-records', methods=['GET'])
@token_required
def get_visit_medical_records(current_user, visit_id):
    visit = Visit.query.get_or_404(visit_id)
    appointment = visit.appointment
    
    # التحقق من الصلاحيات
    if not any(role.name in ['admin', 'nurse'] for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        
        if (doctor and appointment.doctor_id != doctor.id) and (patient and appointment.patient_id != patient.id):
            return jsonify({
                'message': 'غير مصرح لك بالوصول!',
                'message_en': 'Access denied!'
            }), 403
    
    # الحصول على التقارير الطبية
    records = MedicalRecord.query.filter_by(visit_id=visit_id).all()
    
    records_list = []
    for record in records:
        # التحقق من الصلاحيات للتقارير السرية
        if record.is_confidential and not any(role.name in ['admin', 'doctor', 'nurse'] for role in current_user.roles):
            continue
        
        records_list.append({
            'id': record.id,
            'record_type': record.record_type,
            'record_type_ar': record.record_type_ar,
            'title': record.title,
            'title_ar': record.title_ar,
            'content': record.content,
            'content_ar': record.content_ar,
            'file_path': record.file_path,
            'is_confidential': record.is_confidential,
            'created_at': record.created_at.isoformat()
        })
    
    return jsonify({
        'medical_records': records_list
    }), 200
