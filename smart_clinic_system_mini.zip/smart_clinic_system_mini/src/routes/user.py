from flask import Blueprint, request, jsonify
from src.models.all_models import db, User, Role
from src.routes.auth import token_required, role_required

user_bp = Blueprint('user', __name__)

# الحصول على قائمة المستخدمين (للمدير فقط)
@user_bp.route('/', methods=['GET'])
@token_required
@role_required(['admin'])
def get_users(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    users = User.query.paginate(page=page, per_page=per_page, error_out=False)
    
    users_list = []
    for user in users.items:
        user_roles = [{'id': role.id, 'name': role.name, 'name_ar': role.name_ar} for role in user.roles]
        users_list.append({
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'first_name': user.first_name,
            'first_name_ar': user.first_name_ar,
            'last_name': user.last_name,
            'last_name_ar': user.last_name_ar,
            'phone': user.phone,
            'is_active': user.is_active,
            'language_preference': user.language_preference,
            'roles': user_roles,
            'created_at': user.created_at.isoformat()
        })
    
    return jsonify({
        'users': users_list,
        'total': users.total,
        'pages': users.pages,
        'current_page': users.page
    }), 200

# الحصول على مستخدم محدد بواسطة المعرف
@user_bp.route('/<int:user_id>', methods=['GET'])
@token_required
def get_user(current_user, user_id):
    # التحقق من الصلاحيات (المدير أو المستخدم نفسه)
    if not any(role.name == 'admin' for role in current_user.roles) and current_user.id != user_id:
        return jsonify({
            'message': 'غير مصرح لك بالوصول!',
            'message_en': 'Access denied!'
        }), 403
    
    user = User.query.get_or_404(user_id)
    
    user_roles = [{'id': role.id, 'name': role.name, 'name_ar': role.name_ar} for role in user.roles]
    
    return jsonify({
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'first_name': user.first_name,
        'first_name_ar': user.first_name_ar,
        'last_name': user.last_name,
        'last_name_ar': user.last_name_ar,
        'phone': user.phone,
        'is_active': user.is_active,
        'language_preference': user.language_preference,
        'roles': user_roles,
        'created_at': user.created_at.isoformat()
    }), 200

# تحديث بيانات مستخدم
@user_bp.route('/<int:user_id>', methods=['PUT'])
@token_required
def update_user(current_user, user_id):
    # التحقق من الصلاحيات (المدير أو المستخدم نفسه)
    if not any(role.name == 'admin' for role in current_user.roles) and current_user.id != user_id:
        return jsonify({
            'message': 'غير مصرح لك بالوصول!',
            'message_en': 'Access denied!'
        }), 403
    
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    # تحديث البيانات المسموح بها
    if data.get('first_name'):
        user.first_name = data.get('first_name')
    if data.get('first_name_ar'):
        user.first_name_ar = data.get('first_name_ar')
    if data.get('last_name'):
        user.last_name = data.get('last_name')
    if data.get('last_name_ar'):
        user.last_name_ar = data.get('last_name_ar')
    if data.get('phone'):
        user.phone = data.get('phone')
    if data.get('language_preference'):
        user.language_preference = data.get('language_preference')
    
    # تحديث البريد الإلكتروني (التحقق من عدم وجود تكرار)
    if data.get('email') and data.get('email') != user.email:
        if User.query.filter_by(email=data.get('email')).first():
            return jsonify({
                'message': 'البريد الإلكتروني موجود بالفعل!',
                'message_en': 'Email already exists!'
            }), 400
        user.email = data.get('email')
    
    # تحديث حالة النشاط (للمدير فقط)
    if data.get('is_active') is not None and any(role.name == 'admin' for role in current_user.roles):
        user.is_active = data.get('is_active')
    
    # تحديث الأدوار (للمدير فقط)
    if data.get('roles') and any(role.name == 'admin' for role in current_user.roles):
        user.roles = []
        for role_id in data.get('roles'):
            role = Role.query.get(role_id)
            if role:
                user.roles.append(role)
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم تحديث بيانات المستخدم بنجاح!',
        'message_en': 'User updated successfully!'
    }), 200

# حذف مستخدم (للمدير فقط)
@user_bp.route('/<int:user_id>', methods=['DELETE'])
@token_required
@role_required(['admin'])
def delete_user(current_user, user_id):
    user = User.query.get_or_404(user_id)
    
    # منع حذف المستخدم الحالي
    if user.id == current_user.id:
        return jsonify({
            'message': 'لا يمكنك حذف حسابك الحالي!',
            'message_en': 'You cannot delete your current account!'
        }), 400
    
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({
        'message': 'تم حذف المستخدم بنجاح!',
        'message_en': 'User deleted successfully!'
    }), 200

# الحصول على قائمة الأدوار
@user_bp.route('/roles', methods=['GET'])
@token_required
@role_required(['admin'])
def get_roles(current_user):
    roles = Role.query.all()
    
    roles_list = []
    for role in roles:
        roles_list.append({
            'id': role.id,
            'name': role.name,
            'name_ar': role.name_ar,
            'description': role.description,
            'description_ar': role.description_ar
        })
    
    return jsonify({
        'roles': roles_list
    }), 200

# إنشاء دور جديد (للمدير فقط)
@user_bp.route('/roles', methods=['POST'])
@token_required
@role_required(['admin'])
def create_role(current_user):
    data = request.get_json()
    
    if not data or not data.get('name'):
        return jsonify({
            'message': 'اسم الدور مطلوب!',
            'message_en': 'Role name is required!'
        }), 400
    
    if Role.query.filter_by(name=data.get('name')).first():
        return jsonify({
            'message': 'الدور موجود بالفعل!',
            'message_en': 'Role already exists!'
        }), 400
    
    new_role = Role(
        name=data.get('name'),
        name_ar=data.get('name_ar'),
        description=data.get('description'),
        description_ar=data.get('description_ar')
    )
    
    db.session.add(new_role)
    db.session.commit()
    
    return jsonify({
        'message': 'تم إنشاء الدور بنجاح!',
        'message_en': 'Role created successfully!',
        'role_id': new_role.id
    }), 201
