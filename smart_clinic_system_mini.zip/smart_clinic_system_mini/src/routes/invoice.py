from flask import Blueprint, request, jsonify
from src.models.all_models import db, Invoice, InvoiceItem, Visit, Patient
from src.routes.auth import token_required, role_required

invoice_bp = Blueprint('invoice', __name__)

# الحصول على قائمة الفواتير
@invoice_bp.route('/', methods=['GET'])
@token_required
def get_invoices(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # تصفية حسب المريض
    patient_id = request.args.get('patient_id', type=int)
    
    # تصفية حسب التاريخ
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    # تصفية حسب الحالة
    status = request.args.get('status')
    
    query = Invoice.query.join(Visit).join(Visit.appointment)
    
    # تطبيق التصفية حسب الصلاحيات
    if any(role.name in ['admin', 'accountant', 'receptionist'] for role in current_user.roles):
        # المدير والمحاسب وموظف الاستقبال يمكنهم رؤية جميع الفواتير
        pass
    elif any(role.name == 'doctor' for role in current_user.roles):
        # الطبيب يرى فواتير مرضاه فقط
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        if doctor:
            query = query.filter(Visit.appointment.has(doctor_id=doctor.id))
        else:
            return jsonify({
                'message': 'لم يتم العثور على بيانات الطبيب!',
                'message_en': 'Doctor data not found!'
            }), 404
    else:
        # المريض يرى فواتيره فقط
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        if patient:
            query = query.filter(Visit.appointment.has(patient_id=patient.id))
        else:
            return jsonify({
                'message': 'لم يتم العثور على بيانات المريض!',
                'message_en': 'Patient data not found!'
            }), 404
    
    # تطبيق التصفية حسب المعايير
    if patient_id:
        query = query.filter(Visit.appointment.has(patient_id=patient_id))
    if start_date:
        query = query.filter(Invoice.issue_date >= start_date)
    if end_date:
        query = query.filter(Invoice.issue_date <= end_date)
    if status:
        query = query.filter(Invoice.status == status)
    
    # ترتيب الفواتير حسب التاريخ (الأحدث أولاً)
    query = query.order_by(Invoice.issue_date.desc())
    
    invoices = query.paginate(page=page, per_page=per_page, error_out=False)
    
    invoices_list = []
    for invoice in invoices.items:
        visit = invoice.visit
        appointment = visit.appointment
        invoices_list.append({
            'id': invoice.id,
            'invoice_number': invoice.invoice_number,
            'visit_id': invoice.visit_id,
            'patient_id': appointment.patient_id,
            'patient_name': f"{appointment.patient.user.first_name} {appointment.patient.user.last_name}",
            'patient_name_ar': f"{appointment.patient.user.first_name_ar or ''} {appointment.patient.user.last_name_ar or ''}",
            'issue_date': invoice.issue_date.isoformat(),
            'due_date': invoice.due_date.isoformat() if invoice.due_date else None,
            'total_amount': invoice.total_amount,
            'paid_amount': invoice.paid_amount,
            'status': invoice.status,
            'status_ar': invoice.status_ar,
            'created_at': invoice.created_at.isoformat()
        })
    
    return jsonify({
        'invoices': invoices_list,
        'total': invoices.total,
        'pages': invoices.pages,
        'current_page': invoices.page
    }), 200

# الحصول على فاتورة محددة بواسطة المعرف
@invoice_bp.route('/<int:invoice_id>', methods=['GET'])
@token_required
def get_invoice(current_user, invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    visit = invoice.visit
    appointment = visit.appointment
    
    # التحقق من الصلاحيات
    if not any(role.name in ['admin', 'accountant', 'receptionist'] for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        
        if (doctor and appointment.doctor_id != doctor.id) and (patient and appointment.patient_id != patient.id):
            return jsonify({
                'message': 'غير مصرح لك بالوصول!',
                'message_en': 'Access denied!'
            }), 403
    
    # الحصول على عناصر الفاتورة
    invoice_items = InvoiceItem.query.filter_by(invoice_id=invoice.id).all()
    items_list = []
    for item in invoice_items:
        items_list.append({
            'id': item.id,
            'description': item.description,
            'description_ar': item.description_ar,
            'quantity': item.quantity,
            'unit_price': item.unit_price,
            'total_price': item.total_price
        })
    
    return jsonify({
        'id': invoice.id,
        'invoice_number': invoice.invoice_number,
        'visit_id': invoice.visit_id,
        'patient_id': appointment.patient_id,
        'patient_name': f"{appointment.patient.user.first_name} {appointment.patient.user.last_name}",
        'patient_name_ar': f"{appointment.patient.user.first_name_ar or ''} {appointment.patient.user.last_name_ar or ''}",
        'doctor_name': f"د. {appointment.doctor.user.first_name} {appointment.doctor.user.last_name}",
        'doctor_name_ar': f"د. {appointment.doctor.user.first_name_ar or ''} {appointment.doctor.user.last_name_ar or ''}",
        'issue_date': invoice.issue_date.isoformat(),
        'due_date': invoice.due_date.isoformat() if invoice.due_date else None,
        'total_amount': invoice.total_amount,
        'paid_amount': invoice.paid_amount,
        'status': invoice.status,
        'status_ar': invoice.status_ar,
        'payment_method': invoice.payment_method,
        'payment_method_ar': invoice.payment_method_ar,
        'notes': invoice.notes,
        'notes_ar': invoice.notes_ar,
        'items': items_list,
        'created_at': invoice.created_at.isoformat(),
        'updated_at': invoice.updated_at.isoformat()
    }), 200

# إنشاء فاتورة جديدة
@invoice_bp.route('/', methods=['POST'])
@token_required
@role_required(['admin', 'accountant', 'receptionist'])
def create_invoice(current_user):
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data.get('visit_id'):
        return jsonify({
            'message': 'معرف الزيارة مطلوب!',
            'message_en': 'Visit ID is required!'
        }), 400
    
    if not data.get('items') or not isinstance(data.get('items'), list) or len(data.get('items')) == 0:
        return jsonify({
            'message': 'يجب توفير عنصر واحد على الأقل للفاتورة!',
            'message_en': 'At least one invoice item is required!'
        }), 400
    
    # التحقق من وجود الزيارة
    visit = Visit.query.get(data.get('visit_id'))
    if not visit:
        return jsonify({
            'message': 'الزيارة غير موجودة!',
            'message_en': 'Visit not found!'
        }), 404
    
    # التحقق من عدم وجود فاتورة سابقة لهذه الزيارة
    existing_invoice = Invoice.query.filter_by(visit_id=data.get('visit_id')).first()
    if existing_invoice:
        return jsonify({
            'message': 'توجد فاتورة مسجلة بالفعل لهذه الزيارة!',
            'message_en': 'An invoice already exists for this visit!'
        }), 400
    
    # إنشاء رقم فاتورة فريد
    import datetime
    import random
    invoice_number = f"INV-{datetime.datetime.now().strftime('%Y%m%d')}-{random.randint(1000, 9999)}"
    
    # حساب المبلغ الإجمالي
    total_amount = 0
    for item_data in data.get('items'):
        quantity = item_data.get('quantity', 1)
        unit_price = item_data.get('unit_price', 0)
        total_amount += quantity * unit_price
    
    # إنشاء فاتورة جديدة
    new_invoice = Invoice(
        visit_id=data.get('visit_id'),
        invoice_number=invoice_number,
        issue_date=data.get('issue_date'),
        due_date=data.get('due_date'),
        total_amount=total_amount,
        paid_amount=data.get('paid_amount', 0),
        status=data.get('status', 'pending'),
        status_ar=data.get('status_ar', 'قيد الانتظار'),
        payment_method=data.get('payment_method'),
        payment_method_ar=data.get('payment_method_ar'),
        notes=data.get('notes'),
        notes_ar=data.get('notes_ar')
    )
    
    db.session.add(new_invoice)
    db.session.flush()  # للحصول على معرف الفاتورة
    
    # إضافة عناصر الفاتورة
    for item_data in data.get('items'):
        quantity = item_data.get('quantity', 1)
        unit_price = item_data.get('unit_price', 0)
        total_price = quantity * unit_price
        
        new_item = InvoiceItem(
            invoice_id=new_invoice.id,
            description=item_data.get('description'),
            description_ar=item_data.get('description_ar'),
            quantity=quantity,
            unit_price=unit_price,
            total_price=total_price
        )
        db.session.add(new_item)
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم إنشاء الفاتورة بنجاح!',
        'message_en': 'Invoice created successfully!',
        'invoice_id': new_invoice.id,
        'invoice_number': new_invoice.invoice_number
    }), 201

# تحديث فاتورة
@invoice_bp.route('/<int:invoice_id>', methods=['PUT'])
@token_required
@role_required(['admin', 'accountant'])
def update_invoice(current_user, invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    data = request.get_json()
    
    # تحديث البيانات المسموح بها
    if data.get('due_date'):
        invoice.due_date = data.get('due_date')
    if data.get('paid_amount') is not None:
        invoice.paid_amount = data.get('paid_amount')
        
        # تحديث حالة الفاتورة بناءً على المبلغ المدفوع
        if invoice.paid_amount >= invoice.total_amount:
            invoice.status = 'paid'
            invoice.status_ar = 'مدفوعة'
        elif invoice.paid_amount > 0:
            invoice.status = 'partially_paid'
            invoice.status_ar = 'مدفوعة جزئياً'
        else:
            invoice.status = 'pending'
            invoice.status_ar = 'قيد الانتظار'
    
    if data.get('status'):
        invoice.status = data.get('status')
    if data.get('status_ar'):
        invoice.status_ar = data.get('status_ar')
    if data.get('payment_method'):
        invoice.payment_method = data.get('payment_method')
    if data.get('payment_method_ar'):
        invoice.payment_method_ar = data.get('payment_method_ar')
    if data.get('notes'):
        invoice.notes = data.get('notes')
    if data.get('notes_ar'):
        invoice.notes_ar = data.get('notes_ar')
    
    # تحديث عناصر الفاتورة إذا تم توفيرها
    if data.get('items') and isinstance(data.get('items'), list) and len(data.get('items')) > 0:
        # حذف العناصر الحالية
        InvoiceItem.query.filter_by(invoice_id=invoice.id).delete()
        
        # إعادة حساب المبلغ الإجمالي
        total_amount = 0
        
        # إضافة العناصر الجديدة
        for item_data in data.get('items'):
            quantity = item_data.get('quantity', 1)
            unit_price = item_data.get('unit_price', 0)
            total_price = quantity * unit_price
            total_amount += total_price
            
            new_item = InvoiceItem(
                invoice_id=invoice.id,
                description=item_data.get('description'),
                description_ar=item_data.get('description_ar'),
                quantity=quantity,
                unit_price=unit_price,
                total_price=total_price
            )
            db.session.add(new_item)
        
        # تحديث المبلغ الإجمالي
        invoice.total_amount = total_amount
        
        # تحديث حالة الفاتورة بناءً على المبلغ المدفوع
        if invoice.paid_amount >= total_amount:
            invoice.status = 'paid'
            invoice.status_ar = 'مدفوعة'
        elif invoice.paid_amount > 0:
            invoice.status = 'partially_paid'
            invoice.status_ar = 'مدفوعة جزئياً'
        else:
            invoice.status = 'pending'
            invoice.status_ar = 'قيد الانتظار'
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم تحديث الفاتورة بنجاح!',
        'message_en': 'Invoice updated successfully!'
    }), 200

# تسجيل دفعة للفاتورة
@invoice_bp.route('/<int:invoice_id>/payment', methods=['POST'])
@token_required
@role_required(['admin', 'accountant', 'receptionist'])
def add_payment(current_user, invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if data.get('amount') is None:
        return jsonify({
            'message': 'مبلغ الدفعة مطلوب!',
            'message_en': 'Payment amount is required!'
        }), 400
    
    amount = float(data.get('amount'))
    if amount <= 0:
        return jsonify({
            'message': 'يجب أن يكون مبلغ الدفعة أكبر من صفر!',
            'message_en': 'Payment amount must be greater than zero!'
        }), 400
    
    # تحديث المبلغ المدفوع
    invoice.paid_amount += amount
    
    # تحديث طريقة الدفع
    if data.get('payment_method'):
        invoice.payment_method = data.get('payment_method')
    if data.get('payment_method_ar'):
        invoice.payment_method_ar = data.get('payment_method_ar')
    
    # تحديث حالة الفاتورة
    if invoice.paid_amount >= invoice.total_amount:
        invoice.status = 'paid'
        invoice.status_ar = 'مدفوعة'
    else:
        invoice.status = 'partially_paid'
        invoice.status_ar = 'مدفوعة جزئياً'
    
    # إضافة ملاحظات الدفع
    if data.get('notes'):
        if invoice.notes:
            invoice.notes += f"\n{data.get('notes')}"
        else:
            invoice.notes = data.get('notes')
    
    if data.get('notes_ar'):
        if invoice.notes_ar:
            invoice.notes_ar += f"\n{data.get('notes_ar')}"
        else:
            invoice.notes_ar = data.get('notes_ar')
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم تسجيل الدفعة بنجاح!',
        'message_en': 'Payment recorded successfully!',
        'paid_amount': invoice.paid_amount,
        'remaining_amount': invoice.total_amount - invoice.paid_amount,
        'status': invoice.status
    }), 200

# إلغاء فاتورة
@invoice_bp.route('/<int:invoice_id>/cancel', methods=['PUT'])
@token_required
@role_required(['admin', 'accountant'])
def cancel_invoice(current_user, invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    
    # التحقق من أن الفاتورة ليست ملغاة بالفعل
    if invoice.status == 'cancelled':
        return jsonify({
            'message': 'الفاتورة ملغاة بالفعل!',
            'message_en': 'Invoice is already cancelled!'
        }), 400
    
    # إلغاء الفاتورة
    invoice.status = 'cancelled'
    invoice.status_ar = 'ملغاة'
    
    # إضافة سبب الإلغاء إذا تم توفيره
    data = request.get_json()
    if data and data.get('cancellation_reason'):
        if invoice.notes:
            invoice.notes += f"\nسبب الإلغاء: {data.get('cancellation_reason')}"
        else:
            invoice.notes = f"سبب الإلغاء: {data.get('cancellation_reason')}"
    
    if data and data.get('cancellation_reason_ar'):
        if invoice.notes_ar:
            invoice.notes_ar += f"\nسبب الإلغاء: {data.get('cancellation_reason_ar')}"
        else:
            invoice.notes_ar = f"سبب الإلغاء: {data.get('cancellation_reason_ar')}"
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم إلغاء الفاتورة بنجاح!',
        'message_en': 'Invoice cancelled successfully!'
    }), 200

# حذف فاتورة (للمدير فقط)
@invoice_bp.route('/<int:invoice_id>', methods=['DELETE'])
@token_required
@role_required(['admin'])
def delete_invoice(current_user, invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    
    db.session.delete(invoice)
    db.session.commit()
    
    return jsonify({
        'message': 'تم حذف الفاتورة بنجاح!',
        'message_en': 'Invoice deleted successfully!'
    }), 200
