from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import datetime
from functools import wraps
from src.models.all_models import db, User, Role

auth_bp = Blueprint('auth', __name__)

# إنشاء توكن التوثيق
def create_token(user_id):
    payload = {
        'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1),
        'iat': datetime.datetime.utcnow(),
        'sub': user_id
    }
    return jwt.encode(
        payload,
        'SECRET_KEY_CHANGE_IN_PRODUCTION',
        algorithm='HS256'
    )

# دالة للتحقق من التوكن
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({'message': 'توكن التوثيق مفقود!', 'message_en': 'Authentication token is missing!'}), 401
        
        try:
            data = jwt.decode(token, 'SECRET_KEY_CHANGE_IN_PRODUCTION', algorithms=['HS256'])
            current_user = User.query.filter_by(id=data['sub']).first()
            if not current_user:
                return jsonify({'message': 'المستخدم غير موجود!', 'message_en': 'User not found!'}), 401
        except:
            return jsonify({'message': 'توكن غير صالح!', 'message_en': 'Invalid token!'}), 401
        
        return f(current_user, *args, **kwargs)
    
    return decorated

# دالة للتحقق من الصلاحيات
def role_required(role_names):
    def decorator(f):
        @wraps(f)
        def decorated_function(current_user, *args, **kwargs):
            if not any(role.name in role_names for role in current_user.roles):
                return jsonify({'message': 'غير مصرح لك بالوصول!', 'message_en': 'Access denied!'}), 403
            return f(current_user, *args, **kwargs)
        return decorated_function
    return decorator

# تسجيل الدخول
@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({
            'message': 'يرجى توفير اسم المستخدم وكلمة المرور!',
            'message_en': 'Please provide username and password!'
        }), 400
    
    user = User.query.filter_by(username=data.get('username')).first()
    
    if not user or not user.verify_password(data.get('password')):
        return jsonify({
            'message': 'اسم المستخدم أو كلمة المرور غير صحيحة!',
            'message_en': 'Invalid username or password!'
        }), 401
    
    if not user.is_active:
        return jsonify({
            'message': 'هذا الحساب غير نشط!',
            'message_en': 'This account is inactive!'
        }), 401
    
    # تحديث آخر تسجيل دخول
    user.last_login = datetime.datetime.utcnow()
    db.session.commit()
    
    # إنشاء توكن
    token = create_token(user.id)
    
    # تحضير معلومات المستخدم
    user_roles = [{'id': role.id, 'name': role.name, 'name_ar': role.name_ar} for role in user.roles]
    
    return jsonify({
        'message': 'تم تسجيل الدخول بنجاح!',
        'message_en': 'Login successful!',
        'token': token,
        'user': {
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'first_name': user.first_name,
            'first_name_ar': user.first_name_ar,
            'last_name': user.last_name,
            'last_name_ar': user.last_name_ar,
            'language_preference': user.language_preference,
            'roles': user_roles
        }
    }), 200

# تسجيل مستخدم جديد
@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    required_fields = ['username', 'email', 'password', 'first_name', 'last_name']
    for field in required_fields:
        if not data.get(field):
            return jsonify({
                'message': f'حقل {field} مطلوب!',
                'message_en': f'Field {field} is required!'
            }), 400
    
    # التحقق من عدم وجود مستخدم بنفس اسم المستخدم أو البريد الإلكتروني
    if User.query.filter_by(username=data.get('username')).first():
        return jsonify({
            'message': 'اسم المستخدم موجود بالفعل!',
            'message_en': 'Username already exists!'
        }), 400
    
    if User.query.filter_by(email=data.get('email')).first():
        return jsonify({
            'message': 'البريد الإلكتروني موجود بالفعل!',
            'message_en': 'Email already exists!'
        }), 400
    
    # إنشاء مستخدم جديد
    new_user = User(
        username=data.get('username'),
        email=data.get('email'),
        first_name=data.get('first_name'),
        first_name_ar=data.get('first_name_ar'),
        last_name=data.get('last_name'),
        last_name_ar=data.get('last_name_ar'),
        phone=data.get('phone'),
        language_preference=data.get('language_preference', 'ar')
    )
    
    # تعيين كلمة المرور
    new_user.password = data.get('password')
    
    # إضافة دور المريض افتراضياً
    patient_role = Role.query.filter_by(name='patient').first()
    if not patient_role:
        # إنشاء دور المريض إذا لم يكن موجوداً
        patient_role = Role(name='patient', name_ar='مريض', description='Patient role', description_ar='دور المريض')
        db.session.add(patient_role)
        db.session.commit()
    
    new_user.roles.append(patient_role)
    
    # حفظ المستخدم في قاعدة البيانات
    db.session.add(new_user)
    db.session.commit()
    
    return jsonify({
        'message': 'تم تسجيل المستخدم بنجاح!',
        'message_en': 'User registered successfully!',
        'user_id': new_user.id
    }), 201

# تغيير كلمة المرور
@auth_bp.route('/change-password', methods=['POST'])
@token_required
def change_password(current_user):
    data = request.get_json()
    
    if not data or not data.get('current_password') or not data.get('new_password'):
        return jsonify({
            'message': 'يرجى توفير كلمة المرور الحالية والجديدة!',
            'message_en': 'Please provide current and new password!'
        }), 400
    
    if not current_user.verify_password(data.get('current_password')):
        return jsonify({
            'message': 'كلمة المرور الحالية غير صحيحة!',
            'message_en': 'Current password is incorrect!'
        }), 401
    
    current_user.password = data.get('new_password')
    db.session.commit()
    
    return jsonify({
        'message': 'تم تغيير كلمة المرور بنجاح!',
        'message_en': 'Password changed successfully!'
    }), 200

# الحصول على معلومات المستخدم الحالي
@auth_bp.route('/me', methods=['GET'])
@token_required
def get_me(current_user):
    user_roles = [{'id': role.id, 'name': role.name, 'name_ar': role.name_ar} for role in current_user.roles]
    
    return jsonify({
        'id': current_user.id,
        'username': current_user.username,
        'email': current_user.email,
        'first_name': current_user.first_name,
        'first_name_ar': current_user.first_name_ar,
        'last_name': current_user.last_name,
        'last_name_ar': current_user.last_name_ar,
        'phone': current_user.phone,
        'language_preference': current_user.language_preference,
        'roles': user_roles,
        'last_login': current_user.last_login.isoformat() if current_user.last_login else None,
        'created_at': current_user.created_at.isoformat()
    }), 200

# تسجيل الخروج (لا يتطلب عملية خاصة في الخلفية، يتم التعامل معه في الواجهة الأمامية)
@auth_bp.route('/logout', methods=['POST'])
@token_required
def logout(current_user):
    return jsonify({
        'message': 'تم تسجيل الخروج بنجاح!',
        'message_en': 'Logged out successfully!'
    }), 200
