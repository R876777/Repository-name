from flask import Blueprint, request, jsonify
from src.models.all_models import db, Patient, User
from src.routes.auth import token_required, role_required

patient_bp = Blueprint('patient', __name__)

# الحصول على قائمة المرضى (للأطباء والإداريين)
@patient_bp.route('/', methods=['GET'])
@token_required
@role_required(['admin', 'doctor', 'nurse', 'receptionist'])
def get_patients(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    search = request.args.get('search', '')
    
    query = Patient.query
    
    # البحث في بيانات المريض
    if search:
        query = query.join(User).filter(
            (User.first_name.like(f'%{search}%')) |
            (User.first_name_ar.like(f'%{search}%')) |
            (User.last_name.like(f'%{search}%')) |
            (User.last_name_ar.like(f'%{search}%')) |
            (User.email.like(f'%{search}%')) |
            (User.phone.like(f'%{search}%'))
        )
    
    patients = query.paginate(page=page, per_page=per_page, error_out=False)
    
    patients_list = []
    for patient in patients.items:
        patients_list.append({
            'id': patient.id,
            'user_id': patient.user_id,
            'first_name': patient.user.first_name,
            'first_name_ar': patient.user.first_name_ar,
            'last_name': patient.user.last_name,
            'last_name_ar': patient.user.last_name_ar,
            'email': patient.user.email,
            'phone': patient.user.phone,
            'gender': patient.gender,
            'date_of_birth': patient.date_of_birth.isoformat() if patient.date_of_birth else None,
            'blood_type': patient.blood_type,
            'created_at': patient.created_at.isoformat()
        })
    
    return jsonify({
        'patients': patients_list,
        'total': patients.total,
        'pages': patients.pages,
        'current_page': patients.page
    }), 200

# الحصول على مريض محدد بواسطة المعرف
@patient_bp.route('/<int:patient_id>', methods=['GET'])
@token_required
def get_patient(current_user, patient_id):
    # التحقق من الصلاحيات (المدير أو الطبيب أو الممرض أو المريض نفسه)
    patient = Patient.query.get_or_404(patient_id)
    
    if not any(role.name in ['admin', 'doctor', 'nurse', 'receptionist'] for role in current_user.roles) and patient.user_id != current_user.id:
        return jsonify({
            'message': 'غير مصرح لك بالوصول!',
            'message_en': 'Access denied!'
        }), 403
    
    return jsonify({
        'id': patient.id,
        'user_id': patient.user_id,
        'first_name': patient.user.first_name,
        'first_name_ar': patient.user.first_name_ar,
        'last_name': patient.user.last_name,
        'last_name_ar': patient.user.last_name_ar,
        'email': patient.user.email,
        'phone': patient.user.phone,
        'gender': patient.gender,
        'date_of_birth': patient.date_of_birth.isoformat() if patient.date_of_birth else None,
        'blood_type': patient.blood_type,
        'address': patient.address,
        'address_ar': patient.address_ar,
        'emergency_contact_name': patient.emergency_contact_name,
        'emergency_contact_name_ar': patient.emergency_contact_name_ar,
        'emergency_contact_phone': patient.emergency_contact_phone,
        'emergency_contact_relation': patient.emergency_contact_relation,
        'emergency_contact_relation_ar': patient.emergency_contact_relation_ar,
        'medical_history': patient.medical_history,
        'medical_history_ar': patient.medical_history_ar,
        'allergies': patient.allergies,
        'allergies_ar': patient.allergies_ar,
        'chronic_diseases': patient.chronic_diseases,
        'chronic_diseases_ar': patient.chronic_diseases_ar,
        'created_at': patient.created_at.isoformat(),
        'updated_at': patient.updated_at.isoformat()
    }), 200

# إنشاء مريض جديد
@patient_bp.route('/', methods=['POST'])
@token_required
@role_required(['admin', 'receptionist'])
def create_patient(current_user):
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    required_fields = ['user_id', 'gender', 'date_of_birth']
    for field in required_fields:
        if not data.get(field):
            return jsonify({
                'message': f'حقل {field} مطلوب!',
                'message_en': f'Field {field} is required!'
            }), 400
    
    # التحقق من عدم وجود مريض بنفس معرف المستخدم
    if Patient.query.filter_by(user_id=data.get('user_id')).first():
        return jsonify({
            'message': 'المريض موجود بالفعل!',
            'message_en': 'Patient already exists!'
        }), 400
    
    # التحقق من وجود المستخدم
    user = User.query.get(data.get('user_id'))
    if not user:
        return jsonify({
            'message': 'المستخدم غير موجود!',
            'message_en': 'User not found!'
        }), 404
    
    # إنشاء مريض جديد
    new_patient = Patient(
        user_id=data.get('user_id'),
        gender=data.get('gender'),
        date_of_birth=data.get('date_of_birth'),
        blood_type=data.get('blood_type'),
        address=data.get('address'),
        address_ar=data.get('address_ar'),
        emergency_contact_name=data.get('emergency_contact_name'),
        emergency_contact_name_ar=data.get('emergency_contact_name_ar'),
        emergency_contact_phone=data.get('emergency_contact_phone'),
        emergency_contact_relation=data.get('emergency_contact_relation'),
        emergency_contact_relation_ar=data.get('emergency_contact_relation_ar'),
        medical_history=data.get('medical_history'),
        medical_history_ar=data.get('medical_history_ar'),
        allergies=data.get('allergies'),
        allergies_ar=data.get('allergies_ar'),
        chronic_diseases=data.get('chronic_diseases'),
        chronic_diseases_ar=data.get('chronic_diseases_ar')
    )
    
    # إضافة دور المريض للمستخدم إذا لم يكن موجوداً
    patient_role = Role.query.filter_by(name='patient').first()
    if patient_role and patient_role not in user.roles:
        user.roles.append(patient_role)
    
    db.session.add(new_patient)
    db.session.commit()
    
    return jsonify({
        'message': 'تم إنشاء المريض بنجاح!',
        'message_en': 'Patient created successfully!',
        'patient_id': new_patient.id
    }), 201

# تحديث بيانات مريض
@patient_bp.route('/<int:patient_id>', methods=['PUT'])
@token_required
def update_patient(current_user, patient_id):
    # التحقق من الصلاحيات (المدير أو الطبيب أو الممرض أو المريض نفسه)
    patient = Patient.query.get_or_404(patient_id)
    
    if not any(role.name in ['admin', 'doctor', 'nurse', 'receptionist'] for role in current_user.roles) and patient.user_id != current_user.id:
        return jsonify({
            'message': 'غير مصرح لك بالوصول!',
            'message_en': 'Access denied!'
        }), 403
    
    data = request.get_json()
    
    # تحديث البيانات المسموح بها
    if data.get('gender'):
        patient.gender = data.get('gender')
    if data.get('date_of_birth'):
        patient.date_of_birth = data.get('date_of_birth')
    if data.get('blood_type'):
        patient.blood_type = data.get('blood_type')
    if data.get('address'):
        patient.address = data.get('address')
    if data.get('address_ar'):
        patient.address_ar = data.get('address_ar')
    if data.get('emergency_contact_name'):
        patient.emergency_contact_name = data.get('emergency_contact_name')
    if data.get('emergency_contact_name_ar'):
        patient.emergency_contact_name_ar = data.get('emergency_contact_name_ar')
    if data.get('emergency_contact_phone'):
        patient.emergency_contact_phone = data.get('emergency_contact_phone')
    if data.get('emergency_contact_relation'):
        patient.emergency_contact_relation = data.get('emergency_contact_relation')
    if data.get('emergency_contact_relation_ar'):
        patient.emergency_contact_relation_ar = data.get('emergency_contact_relation_ar')
    if data.get('medical_history'):
        patient.medical_history = data.get('medical_history')
    if data.get('medical_history_ar'):
        patient.medical_history_ar = data.get('medical_history_ar')
    if data.get('allergies'):
        patient.allergies = data.get('allergies')
    if data.get('allergies_ar'):
        patient.allergies_ar = data.get('allergies_ar')
    if data.get('chronic_diseases'):
        patient.chronic_diseases = data.get('chronic_diseases')
    if data.get('chronic_diseases_ar'):
        patient.chronic_diseases_ar = data.get('chronic_diseases_ar')
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم تحديث بيانات المريض بنجاح!',
        'message_en': 'Patient updated successfully!'
    }), 200

# حذف مريض (للمدير فقط)
@patient_bp.route('/<int:patient_id>', methods=['DELETE'])
@token_required
@role_required(['admin'])
def delete_patient(current_user, patient_id):
    patient = Patient.query.get_or_404(patient_id)
    
    db.session.delete(patient)
    db.session.commit()
    
    return jsonify({
        'message': 'تم حذف المريض بنجاح!',
        'message_en': 'Patient deleted successfully!'
    }), 200
