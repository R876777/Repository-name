from flask import Blueprint, request, jsonify
from datetime import datetime, date, time
from src.models.all_models import db, Appointment, Patient, Doctor
from src.routes.auth import token_required, role_required

appointment_bp = Blueprint('appointment', __name__)

# الحصول على قائمة المواعيد
@appointment_bp.route('/', methods=['GET'])
@token_required
def get_appointments(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # تصفية حسب التاريخ
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    # تصفية حسب الطبيب أو المريض
    doctor_id = request.args.get('doctor_id', type=int)
    patient_id = request.args.get('patient_id', type=int)
    
    # تصفية حسب الحالة
    status = request.args.get('status')
    
    query = Appointment.query
    
    # تطبيق التصفية حسب الصلاحيات
    if any(role.name == 'admin' for role in current_user.roles):
        # المدير يمكنه رؤية جميع المواعيد
        pass
    elif any(role.name == 'doctor' for role in current_user.roles):
        # الطبيب يرى مواعيده فقط
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        if doctor:
            query = query.filter_by(doctor_id=doctor.id)
        else:
            return jsonify({
                'message': 'لم يتم العثور على بيانات الطبيب!',
                'message_en': 'Doctor data not found!'
            }), 404
    elif any(role.name == 'receptionist' for role in current_user.roles):
        # موظف الاستقبال يرى جميع المواعيد
        pass
    else:
        # المريض يرى مواعيده فقط
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        if patient:
            query = query.filter_by(patient_id=patient.id)
        else:
            return jsonify({
                'message': 'لم يتم العثور على بيانات المريض!',
                'message_en': 'Patient data not found!'
            }), 404
    
    # تطبيق التصفية حسب المعايير
    if start_date:
        query = query.filter(Appointment.appointment_date >= start_date)
    if end_date:
        query = query.filter(Appointment.appointment_date <= end_date)
    if doctor_id:
        query = query.filter_by(doctor_id=doctor_id)
    if patient_id:
        query = query.filter_by(patient_id=patient_id)
    if status:
        query = query.filter_by(status=status)
    
    # ترتيب المواعيد حسب التاريخ والوقت
    query = query.order_by(Appointment.appointment_date, Appointment.start_time)
    
    appointments = query.paginate(page=page, per_page=per_page, error_out=False)
    
    appointments_list = []
    for appointment in appointments.items:
        appointments_list.append({
            'id': appointment.id,
            'patient_id': appointment.patient_id,
            'patient_name': f"{appointment.patient.user.first_name} {appointment.patient.user.last_name}",
            'patient_name_ar': f"{appointment.patient.user.first_name_ar or ''} {appointment.patient.user.last_name_ar or ''}",
            'doctor_id': appointment.doctor_id,
            'doctor_name': f"د. {appointment.doctor.user.first_name} {appointment.doctor.user.last_name}",
            'doctor_name_ar': f"د. {appointment.doctor.user.first_name_ar or ''} {appointment.doctor.user.last_name_ar or ''}",
            'doctor_specialization': appointment.doctor.specialization,
            'doctor_specialization_ar': appointment.doctor.specialization_ar,
            'appointment_date': appointment.appointment_date.isoformat(),
            'start_time': appointment.start_time.strftime('%H:%M'),
            'end_time': appointment.end_time.strftime('%H:%M'),
            'status': appointment.status,
            'status_ar': appointment.status_ar,
            'appointment_type': appointment.appointment_type,
            'appointment_type_ar': appointment.appointment_type_ar,
            'reason': appointment.reason,
            'created_at': appointment.created_at.isoformat()
        })
    
    return jsonify({
        'appointments': appointments_list,
        'total': appointments.total,
        'pages': appointments.pages,
        'current_page': appointments.page
    }), 200

# الحصول على موعد محدد بواسطة المعرف
@appointment_bp.route('/<int:appointment_id>', methods=['GET'])
@token_required
def get_appointment(current_user, appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    
    # التحقق من الصلاحيات
    if not any(role.name in ['admin', 'receptionist'] for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        
        if (doctor and appointment.doctor_id != doctor.id) and (patient and appointment.patient_id != patient.id):
            return jsonify({
                'message': 'غير مصرح لك بالوصول!',
                'message_en': 'Access denied!'
            }), 403
    
    return jsonify({
        'id': appointment.id,
        'patient_id': appointment.patient_id,
        'patient_name': f"{appointment.patient.user.first_name} {appointment.patient.user.last_name}",
        'patient_name_ar': f"{appointment.patient.user.first_name_ar or ''} {appointment.patient.user.last_name_ar or ''}",
        'doctor_id': appointment.doctor_id,
        'doctor_name': f"د. {appointment.doctor.user.first_name} {appointment.doctor.user.last_name}",
        'doctor_name_ar': f"د. {appointment.doctor.user.first_name_ar or ''} {appointment.doctor.user.last_name_ar or ''}",
        'doctor_specialization': appointment.doctor.specialization,
        'doctor_specialization_ar': appointment.doctor.specialization_ar,
        'appointment_date': appointment.appointment_date.isoformat(),
        'start_time': appointment.start_time.strftime('%H:%M'),
        'end_time': appointment.end_time.strftime('%H:%M'),
        'status': appointment.status,
        'status_ar': appointment.status_ar,
        'appointment_type': appointment.appointment_type,
        'appointment_type_ar': appointment.appointment_type_ar,
        'reason': appointment.reason,
        'reason_ar': appointment.reason_ar,
        'notes': appointment.notes,
        'notes_ar': appointment.notes_ar,
        'created_at': appointment.created_at.isoformat(),
        'updated_at': appointment.updated_at.isoformat()
    }), 200

# إنشاء موعد جديد
@appointment_bp.route('/', methods=['POST'])
@token_required
def create_appointment(current_user):
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    required_fields = ['patient_id', 'doctor_id', 'appointment_date', 'start_time', 'end_time']
    for field in required_fields:
        if not data.get(field):
            return jsonify({
                'message': f'حقل {field} مطلوب!',
                'message_en': f'Field {field} is required!'
            }), 400
    
    # التحقق من وجود المريض والطبيب
    patient = Patient.query.get(data.get('patient_id'))
    if not patient:
        return jsonify({
            'message': 'المريض غير موجود!',
            'message_en': 'Patient not found!'
        }), 404
    
    doctor = Doctor.query.get(data.get('doctor_id'))
    if not doctor:
        return jsonify({
            'message': 'الطبيب غير موجود!',
            'message_en': 'Doctor not found!'
        }), 404
    
    # التحقق من توفر الطبيب
    if not doctor.is_available:
        return jsonify({
            'message': 'الطبيب غير متاح حالياً!',
            'message_en': 'Doctor is not available!'
        }), 400
    
    # التحقق من عدم وجود تعارض في المواعيد
    appointment_date = datetime.strptime(data.get('appointment_date'), '%Y-%m-%d').date()
    start_time = datetime.strptime(data.get('start_time'), '%H:%M').time()
    end_time = datetime.strptime(data.get('end_time'), '%H:%M').time()
    
    # التحقق من أن وقت البداية قبل وقت النهاية
    if start_time >= end_time:
        return jsonify({
            'message': 'وقت البداية يجب أن يكون قبل وقت النهاية!',
            'message_en': 'Start time must be before end time!'
        }), 400
    
    # التحقق من عدم وجود تعارض مع مواعيد الطبيب الأخرى
    conflicting_appointments = Appointment.query.filter(
        Appointment.doctor_id == doctor.id,
        Appointment.appointment_date == appointment_date,
        Appointment.status != 'cancelled',
        ((Appointment.start_time <= start_time) & (Appointment.end_time > start_time)) |
        ((Appointment.start_time < end_time) & (Appointment.end_time >= end_time)) |
        ((Appointment.start_time >= start_time) & (Appointment.end_time <= end_time))
    ).all()
    
    if conflicting_appointments:
        return jsonify({
            'message': 'يوجد تعارض مع مواعيد أخرى للطبيب!',
            'message_en': 'Conflict with other doctor appointments!'
        }), 400
    
    # إنشاء موعد جديد
    new_appointment = Appointment(
        patient_id=data.get('patient_id'),
        doctor_id=data.get('doctor_id'),
        appointment_date=appointment_date,
        start_time=start_time,
        end_time=end_time,
        status=data.get('status', 'pending'),
        status_ar=data.get('status_ar', 'قيد الانتظار'),
        appointment_type=data.get('appointment_type', 'regular'),
        appointment_type_ar=data.get('appointment_type_ar', 'عادي'),
        reason=data.get('reason'),
        reason_ar=data.get('reason_ar'),
        notes=data.get('notes'),
        notes_ar=data.get('notes_ar')
    )
    
    db.session.add(new_appointment)
    db.session.commit()
    
    return jsonify({
        'message': 'تم إنشاء الموعد بنجاح!',
        'message_en': 'Appointment created successfully!',
        'appointment_id': new_appointment.id
    }), 201

# تحديث موعد
@appointment_bp.route('/<int:appointment_id>', methods=['PUT'])
@token_required
def update_appointment(current_user, appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    
    # التحقق من الصلاحيات
    if not any(role.name in ['admin', 'receptionist', 'doctor'] for role in current_user.roles):
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        if not patient or appointment.patient_id != patient.id:
            return jsonify({
                'message': 'غير مصرح لك بالوصول!',
                'message_en': 'Access denied!'
            }), 403
    
    data = request.get_json()
    
    # تحديث البيانات المسموح بها
    if data.get('status'):
        appointment.status = data.get('status')
    if data.get('status_ar'):
        appointment.status_ar = data.get('status_ar')
    if data.get('notes'):
        appointment.notes = data.get('notes')
    if data.get('notes_ar'):
        appointment.notes_ar = data.get('notes_ar')
    
    # تحديث التاريخ والوقت (للمدير وموظف الاستقبال فقط)
    if any(role.name in ['admin', 'receptionist'] for role in current_user.roles):
        if data.get('appointment_date'):
            appointment.appointment_date = datetime.strptime(data.get('appointment_date'), '%Y-%m-%d').date()
        if data.get('start_time'):
            appointment.start_time = datetime.strptime(data.get('start_time'), '%H:%M').time()
        if data.get('end_time'):
            appointment.end_time = datetime.strptime(data.get('end_time'), '%H:%M').time()
        if data.get('appointment_type'):
            appointment.appointment_type = data.get('appointment_type')
        if data.get('appointment_type_ar'):
            appointment.appointment_type_ar = data.get('appointment_type_ar')
        if data.get('reason'):
            appointment.reason = data.get('reason')
        if data.get('reason_ar'):
            appointment.reason_ar = data.get('reason_ar')
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم تحديث الموعد بنجاح!',
        'message_en': 'Appointment updated successfully!'
    }), 200

# إلغاء موعد
@appointment_bp.route('/<int:appointment_id>/cancel', methods=['PUT'])
@token_required
def cancel_appointment(current_user, appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    
    # التحقق من الصلاحيات
    if not any(role.name in ['admin', 'receptionist'] for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        
        if (doctor and appointment.doctor_id != doctor.id) and (patient and appointment.patient_id != patient.id):
            return jsonify({
                'message': 'غير مصرح لك بالوصول!',
                'message_en': 'Access denied!'
            }), 403
    
    # التحقق من أن الموعد ليس ملغياً بالفعل
    if appointment.status == 'cancelled':
        return jsonify({
            'message': 'الموعد ملغى بالفعل!',
            'message_en': 'Appointment is already cancelled!'
        }), 400
    
    # إلغاء الموعد
    appointment.status = 'cancelled'
    appointment.status_ar = 'ملغي'
    
    # إضافة سبب الإلغاء إذا تم توفيره
    data = request.get_json()
    if data and data.get('cancellation_reason'):
        appointment.notes = data.get('cancellation_reason')
    if data and data.get('cancellation_reason_ar'):
        appointment.notes_ar = data.get('cancellation_reason_ar')
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم إلغاء الموعد بنجاح!',
        'message_en': 'Appointment cancelled successfully!'
    }), 200

# حذف موعد (للمدير فقط)
@appointment_bp.route('/<int:appointment_id>', methods=['DELETE'])
@token_required
@role_required(['admin'])
def delete_appointment(current_user, appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    
    db.session.delete(appointment)
    db.session.commit()
    
    return jsonify({
        'message': 'تم حذف الموعد بنجاح!',
        'message_en': 'Appointment deleted successfully!'
    }), 200

# الحصول على المواعيد المتاحة للطبيب في تاريخ محدد
@appointment_bp.route('/available-slots', methods=['GET'])
@token_required
def get_available_slots(current_user):
    doctor_id = request.args.get('doctor_id', type=int)
    date_str = request.args.get('date')
    
    if not doctor_id or not date_str:
        return jsonify({
            'message': 'معرف الطبيب والتاريخ مطلوبان!',
            'message_en': 'Doctor ID and date are required!'
        }), 400
    
    doctor = Doctor.query.get_or_404(doctor_id)
    
    # التحقق من توفر الطبيب
    if not doctor.is_available:
        return jsonify({
            'message': 'الطبيب غير متاح حالياً!',
            'message_en': 'Doctor is not available!'
        }), 400
    
    appointment_date = datetime.strptime(date_str, '%Y-%m-%d').date()
    
    # الحصول على مواعيد الطبيب في هذا التاريخ
    existing_appointments = Appointment.query.filter(
        Appointment.doctor_id == doctor_id,
        Appointment.appointment_date == appointment_date,
        Appointment.status != 'cancelled'
    ).order_by(Appointment.start_time).all()
    
    # تحديد ساعات عمل الطبيب
    start_hour = doctor.start_time.hour if doctor.start_time else 9  # افتراضي 9 صباحاً
    end_hour = doctor.end_time.hour if doctor.end_time else 17  # افتراضي 5 مساءً
    
    # إنشاء قائمة بجميع الفترات المتاحة (كل 30 دقيقة)
    all_slots = []
    current_time = time(start_hour, 0)
    end_time = time(end_hour, 0)
    
    while current_time < end_time:
        slot_end = time(current_time.hour + (current_time.minute + 30) // 60, (current_time.minute + 30) % 60)
        all_slots.append({
            'start': current_time.strftime('%H:%M'),
            'end': slot_end.strftime('%H:%M')
        })
        current_time = slot_end
    
    # استبعاد الفترات المحجوزة بالفعل
    available_slots = []
    for slot in all_slots:
        slot_start = datetime.strptime(slot['start'], '%H:%M').time()
        slot_end = datetime.strptime(slot['end'], '%H:%M').time()
        
        is_available = True
        for appointment in existing_appointments:
            if (slot_start >= appointment.start_time and slot_start < appointment.end_time) or \
               (slot_end > appointment.start_time and slot_end <= appointment.end_time) or \
               (slot_start <= appointment.start_time and slot_end >= appointment.end_time):
                is_available = False
                break
        
        if is_available:
            available_slots.append(slot)
    
    return jsonify({
        'doctor_id': doctor_id,
        'doctor_name': f"د. {doctor.user.first_name} {doctor.user.last_name}",
        'doctor_name_ar': f"د. {doctor.user.first_name_ar or ''} {doctor.user.last_name_ar or ''}",
        'date': date_str,
        'available_slots': available_slots
    }), 200
