from flask import Blueprint, request, jsonify
from src.models.all_models import db, Doctor, User, Role
from src.routes.auth import token_required, role_required

doctor_bp = Blueprint('doctor', __name__)

# الحصول على قائمة الأطباء
@doctor_bp.route('/', methods=['GET'])
@token_required
def get_doctors(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    search = request.args.get('search', '')
    specialization = request.args.get('specialization', '')
    
    query = Doctor.query
    
    # البحث في بيانات الطبيب
    if search:
        query = query.join(User).filter(
            (User.first_name.like(f'%{search}%')) |
            (User.first_name_ar.like(f'%{search}%')) |
            (User.last_name.like(f'%{search}%')) |
            (User.last_name_ar.like(f'%{search}%')) |
            (Doctor.specialization.like(f'%{search}%')) |
            (Doctor.specialization_ar.like(f'%{search}%'))
        )
    
    # تصفية حسب التخصص
    if specialization:
        query = query.filter(
            (Doctor.specialization == specialization) |
            (Doctor.specialization_ar == specialization)
        )
    
    doctors = query.paginate(page=page, per_page=per_page, error_out=False)
    
    doctors_list = []
    for doctor in doctors.items:
        doctors_list.append({
            'id': doctor.id,
            'user_id': doctor.user_id,
            'first_name': doctor.user.first_name,
            'first_name_ar': doctor.user.first_name_ar,
            'last_name': doctor.user.last_name,
            'last_name_ar': doctor.user.last_name_ar,
            'email': doctor.user.email,
            'phone': doctor.user.phone,
            'specialization': doctor.specialization,
            'specialization_ar': doctor.specialization_ar,
            'qualification': doctor.qualification,
            'qualification_ar': doctor.qualification_ar,
            'years_of_experience': doctor.years_of_experience,
            'consultation_fee': doctor.consultation_fee,
            'is_available': doctor.is_available,
            'created_at': doctor.created_at.isoformat()
        })
    
    return jsonify({
        'doctors': doctors_list,
        'total': doctors.total,
        'pages': doctors.pages,
        'current_page': doctors.page
    }), 200

# الحصول على طبيب محدد بواسطة المعرف
@doctor_bp.route('/<int:doctor_id>', methods=['GET'])
@token_required
def get_doctor(current_user, doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)
    
    return jsonify({
        'id': doctor.id,
        'user_id': doctor.user_id,
        'first_name': doctor.user.first_name,
        'first_name_ar': doctor.user.first_name_ar,
        'last_name': doctor.user.last_name,
        'last_name_ar': doctor.user.last_name_ar,
        'email': doctor.user.email,
        'phone': doctor.user.phone,
        'specialization': doctor.specialization,
        'specialization_ar': doctor.specialization_ar,
        'qualification': doctor.qualification,
        'qualification_ar': doctor.qualification_ar,
        'license_number': doctor.license_number,
        'years_of_experience': doctor.years_of_experience,
        'bio': doctor.bio,
        'bio_ar': doctor.bio_ar,
        'consultation_fee': doctor.consultation_fee,
        'available_days': doctor.available_days,
        'available_days_ar': doctor.available_days_ar,
        'start_time': doctor.start_time.strftime('%H:%M') if doctor.start_time else None,
        'end_time': doctor.end_time.strftime('%H:%M') if doctor.end_time else None,
        'is_available': doctor.is_available,
        'created_at': doctor.created_at.isoformat(),
        'updated_at': doctor.updated_at.isoformat()
    }), 200

# إنشاء طبيب جديد
@doctor_bp.route('/', methods=['POST'])
@token_required
@role_required(['admin'])
def create_doctor(current_user):
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    required_fields = ['user_id', 'specialization', 'qualification', 'license_number']
    for field in required_fields:
        if not data.get(field):
            return jsonify({
                'message': f'حقل {field} مطلوب!',
                'message_en': f'Field {field} is required!'
            }), 400
    
    # التحقق من عدم وجود طبيب بنفس معرف المستخدم
    if Doctor.query.filter_by(user_id=data.get('user_id')).first():
        return jsonify({
            'message': 'الطبيب موجود بالفعل!',
            'message_en': 'Doctor already exists!'
        }), 400
    
    # التحقق من عدم وجود طبيب بنفس رقم الترخيص
    if Doctor.query.filter_by(license_number=data.get('license_number')).first():
        return jsonify({
            'message': 'رقم الترخيص موجود بالفعل!',
            'message_en': 'License number already exists!'
        }), 400
    
    # التحقق من وجود المستخدم
    user = User.query.get(data.get('user_id'))
    if not user:
        return jsonify({
            'message': 'المستخدم غير موجود!',
            'message_en': 'User not found!'
        }), 404
    
    # إنشاء طبيب جديد
    new_doctor = Doctor(
        user_id=data.get('user_id'),
        specialization=data.get('specialization'),
        specialization_ar=data.get('specialization_ar'),
        qualification=data.get('qualification'),
        qualification_ar=data.get('qualification_ar'),
        license_number=data.get('license_number'),
        years_of_experience=data.get('years_of_experience'),
        bio=data.get('bio'),
        bio_ar=data.get('bio_ar'),
        consultation_fee=data.get('consultation_fee', 0.0),
        available_days=data.get('available_days'),
        available_days_ar=data.get('available_days_ar'),
        start_time=data.get('start_time'),
        end_time=data.get('end_time'),
        is_available=data.get('is_available', True)
    )
    
    # إضافة دور الطبيب للمستخدم
    doctor_role = Role.query.filter_by(name='doctor').first()
    if not doctor_role:
        # إنشاء دور الطبيب إذا لم يكن موجوداً
        doctor_role = Role(name='doctor', name_ar='طبيب', description='Doctor role', description_ar='دور الطبيب')
        db.session.add(doctor_role)
        db.session.commit()
    
    if doctor_role not in user.roles:
        user.roles.append(doctor_role)
    
    db.session.add(new_doctor)
    db.session.commit()
    
    return jsonify({
        'message': 'تم إنشاء الطبيب بنجاح!',
        'message_en': 'Doctor created successfully!',
        'doctor_id': new_doctor.id
    }), 201

# تحديث بيانات طبيب
@doctor_bp.route('/<int:doctor_id>', methods=['PUT'])
@token_required
def update_doctor(current_user, doctor_id):
    # التحقق من الصلاحيات (المدير أو الطبيب نفسه)
    doctor = Doctor.query.get_or_404(doctor_id)
    
    if not any(role.name == 'admin' for role in current_user.roles) and doctor.user_id != current_user.id:
        return jsonify({
            'message': 'غير مصرح لك بالوصول!',
            'message_en': 'Access denied!'
        }), 403
    
    data = request.get_json()
    
    # تحديث البيانات المسموح بها
    if data.get('specialization'):
        doctor.specialization = data.get('specialization')
    if data.get('specialization_ar'):
        doctor.specialization_ar = data.get('specialization_ar')
    if data.get('qualification'):
        doctor.qualification = data.get('qualification')
    if data.get('qualification_ar'):
        doctor.qualification_ar = data.get('qualification_ar')
    if data.get('years_of_experience'):
        doctor.years_of_experience = data.get('years_of_experience')
    if data.get('bio'):
        doctor.bio = data.get('bio')
    if data.get('bio_ar'):
        doctor.bio_ar = data.get('bio_ar')
    if data.get('consultation_fee'):
        doctor.consultation_fee = data.get('consultation_fee')
    if data.get('available_days'):
        doctor.available_days = data.get('available_days')
    if data.get('available_days_ar'):
        doctor.available_days_ar = data.get('available_days_ar')
    if data.get('start_time'):
        doctor.start_time = data.get('start_time')
    if data.get('end_time'):
        doctor.end_time = data.get('end_time')
    if data.get('is_available') is not None:
        doctor.is_available = data.get('is_available')
    
    # تحديث رقم الترخيص (للمدير فقط)
    if data.get('license_number') and any(role.name == 'admin' for role in current_user.roles):
        # التحقق من عدم وجود طبيب آخر بنفس رقم الترخيص
        existing_doctor = Doctor.query.filter_by(license_number=data.get('license_number')).first()
        if existing_doctor and existing_doctor.id != doctor_id:
            return jsonify({
                'message': 'رقم الترخيص موجود بالفعل!',
                'message_en': 'License number already exists!'
            }), 400
        doctor.license_number = data.get('license_number')
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم تحديث بيانات الطبيب بنجاح!',
        'message_en': 'Doctor updated successfully!'
    }), 200

# حذف طبيب (للمدير فقط)
@doctor_bp.route('/<int:doctor_id>', methods=['DELETE'])
@token_required
@role_required(['admin'])
def delete_doctor(current_user, doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)
    
    db.session.delete(doctor)
    db.session.commit()
    
    return jsonify({
        'message': 'تم حذف الطبيب بنجاح!',
        'message_en': 'Doctor deleted successfully!'
    }), 200

# الحصول على قائمة التخصصات
@doctor_bp.route('/specializations', methods=['GET'])
@token_required
def get_specializations(current_user):
    language = request.args.get('language', 'ar')  # ar للعربية، en للإنجليزية
    
    # استخراج جميع التخصصات الفريدة
    if language == 'ar':
        specializations = db.session.query(Doctor.specialization_ar).distinct().all()
        specializations = [s[0] for s in specializations if s[0]]
    else:
        specializations = db.session.query(Doctor.specialization).distinct().all()
        specializations = [s[0] for s in specializations if s[0]]
    
    return jsonify({
        'specializations': specializations
    }), 200
