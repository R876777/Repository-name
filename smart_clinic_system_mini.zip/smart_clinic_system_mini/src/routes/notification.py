from flask import Blueprint, request, jsonify
from src.models.all_models import db, Notification, User
from src.routes.auth import token_required, role_required

notification_bp = Blueprint('notification', __name__)

# الحصول على قائمة الإشعارات للمستخدم الحالي
@notification_bp.route('/', methods=['GET'])
@token_required
def get_notifications(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # تصفية حسب حالة القراءة
    is_read = request.args.get('is_read')
    if is_read is not None:
        is_read = is_read.lower() == 'true'
    
    query = Notification.query.filter_by(user_id=current_user.id)
    
    # تطبيق التصفية حسب حالة القراءة
    if is_read is not None:
        query = query.filter_by(is_read=is_read)
    
    # ترتيب الإشعارات حسب التاريخ (الأحدث أولاً)
    query = query.order_by(Notification.created_at.desc())
    
    notifications = query.paginate(page=page, per_page=per_page, error_out=False)
    
    notifications_list = []
    for notification in notifications.items:
        notifications_list.append({
            'id': notification.id,
            'title': notification.title,
            'title_ar': notification.title_ar,
            'content': notification.content,
            'content_ar': notification.content_ar,
            'notification_type': notification.notification_type,
            'notification_type_ar': notification.notification_type_ar,
            'is_read': notification.is_read,
            'created_at': notification.created_at.isoformat()
        })
    
    return jsonify({
        'notifications': notifications_list,
        'total': notifications.total,
        'pages': notifications.pages,
        'current_page': notifications.page,
        'unread_count': Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
    }), 200

# الحصول على إشعار محدد بواسطة المعرف
@notification_bp.route('/<int:notification_id>', methods=['GET'])
@token_required
def get_notification(current_user, notification_id):
    notification = Notification.query.get_or_404(notification_id)
    
    # التحقق من أن الإشعار ينتمي للمستخدم الحالي
    if notification.user_id != current_user.id and not any(role.name == 'admin' for role in current_user.roles):
        return jsonify({
            'message': 'غير مصرح لك بالوصول!',
            'message_en': 'Access denied!'
        }), 403
    
    return jsonify({
        'id': notification.id,
        'title': notification.title,
        'title_ar': notification.title_ar,
        'content': notification.content,
        'content_ar': notification.content_ar,
        'notification_type': notification.notification_type,
        'notification_type_ar': notification.notification_type_ar,
        'is_read': notification.is_read,
        'created_at': notification.created_at.isoformat(),
        'updated_at': notification.updated_at.isoformat()
    }), 200

# تحديث حالة قراءة الإشعار
@notification_bp.route('/<int:notification_id>/read', methods=['PUT'])
@token_required
def mark_notification_as_read(current_user, notification_id):
    notification = Notification.query.get_or_404(notification_id)
    
    # التحقق من أن الإشعار ينتمي للمستخدم الحالي
    if notification.user_id != current_user.id:
        return jsonify({
            'message': 'غير مصرح لك بالوصول!',
            'message_en': 'Access denied!'
        }), 403
    
    # تحديث حالة القراءة
    notification.is_read = True
    db.session.commit()
    
    return jsonify({
        'message': 'تم تحديث حالة قراءة الإشعار بنجاح!',
        'message_en': 'Notification read status updated successfully!'
    }), 200

# تحديث حالة قراءة جميع الإشعارات
@notification_bp.route('/read-all', methods=['PUT'])
@token_required
def mark_all_notifications_as_read(current_user):
    # تحديث حالة قراءة جميع الإشعارات للمستخدم الحالي
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
    db.session.commit()
    
    return jsonify({
        'message': 'تم تحديث حالة قراءة جميع الإشعارات بنجاح!',
        'message_en': 'All notifications marked as read successfully!'
    }), 200

# إنشاء إشعار جديد (للمدير فقط)
@notification_bp.route('/', methods=['POST'])
@token_required
@role_required(['admin'])
def create_notification(current_user):
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    required_fields = ['user_id', 'title', 'content', 'notification_type']
    for field in required_fields:
        if not data.get(field):
            return jsonify({
                'message': f'حقل {field} مطلوب!',
                'message_en': f'Field {field} is required!'
            }), 400
    
    # التحقق من وجود المستخدم
    user = User.query.get(data.get('user_id'))
    if not user:
        return jsonify({
            'message': 'المستخدم غير موجود!',
            'message_en': 'User not found!'
        }), 404
    
    # إنشاء إشعار جديد
    new_notification = Notification(
        user_id=data.get('user_id'),
        title=data.get('title'),
        title_ar=data.get('title_ar'),
        content=data.get('content'),
        content_ar=data.get('content_ar'),
        notification_type=data.get('notification_type'),
        notification_type_ar=data.get('notification_type_ar')
    )
    
    db.session.add(new_notification)
    db.session.commit()
    
    return jsonify({
        'message': 'تم إنشاء الإشعار بنجاح!',
        'message_en': 'Notification created successfully!',
        'notification_id': new_notification.id
    }), 201

# إرسال إشعار لمجموعة من المستخدمين (للمدير فقط)
@notification_bp.route('/bulk', methods=['POST'])
@token_required
@role_required(['admin'])
def create_bulk_notifications(current_user):
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data.get('user_ids') or not isinstance(data.get('user_ids'), list) or len(data.get('user_ids')) == 0:
        return jsonify({
            'message': 'قائمة معرفات المستخدمين مطلوبة!',
            'message_en': 'User IDs list is required!'
        }), 400
    
    required_fields = ['title', 'content', 'notification_type']
    for field in required_fields:
        if not data.get(field):
            return jsonify({
                'message': f'حقل {field} مطلوب!',
                'message_en': f'Field {field} is required!'
            }), 400
    
    # إنشاء إشعارات لجميع المستخدمين المحددين
    created_count = 0
    for user_id in data.get('user_ids'):
        # التحقق من وجود المستخدم
        user = User.query.get(user_id)
        if not user:
            continue
        
        # إنشاء إشعار جديد
        new_notification = Notification(
            user_id=user_id,
            title=data.get('title'),
            title_ar=data.get('title_ar'),
            content=data.get('content'),
            content_ar=data.get('content_ar'),
            notification_type=data.get('notification_type'),
            notification_type_ar=data.get('notification_type_ar')
        )
        
        db.session.add(new_notification)
        created_count += 1
    
    db.session.commit()
    
    return jsonify({
        'message': f'تم إنشاء {created_count} إشعار بنجاح!',
        'message_en': f'{created_count} notifications created successfully!',
        'created_count': created_count
    }), 201

# حذف إشعار
@notification_bp.route('/<int:notification_id>', methods=['DELETE'])
@token_required
def delete_notification(current_user, notification_id):
    notification = Notification.query.get_or_404(notification_id)
    
    # التحقق من أن الإشعار ينتمي للمستخدم الحالي أو المستخدم هو مدير
    if notification.user_id != current_user.id and not any(role.name == 'admin' for role in current_user.roles):
        return jsonify({
            'message': 'غير مصرح لك بالوصول!',
            'message_en': 'Access denied!'
        }), 403
    
    db.session.delete(notification)
    db.session.commit()
    
    return jsonify({
        'message': 'تم حذف الإشعار بنجاح!',
        'message_en': 'Notification deleted successfully!'
    }), 200
