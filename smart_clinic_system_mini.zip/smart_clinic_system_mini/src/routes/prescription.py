from flask import Blueprint, request, jsonify
from src.models.all_models import db, Prescription, PrescriptionItem, Visit, Doctor
from src.routes.auth import token_required, role_required

prescription_bp = Blueprint('prescription', __name__)

# الحصول على قائمة الوصفات الطبية
@prescription_bp.route('/', methods=['GET'])
@token_required
def get_prescriptions(current_user):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # تصفية حسب المريض أو الطبيب
    patient_id = request.args.get('patient_id', type=int)
    doctor_id = request.args.get('doctor_id', type=int)
    
    # تصفية حسب التاريخ
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    query = Prescription.query.join(Visit).join(Visit.appointment)
    
    # تطبيق التصفية حسب الصلاحيات
    if any(role.name == 'admin' for role in current_user.roles):
        # المدير يمكنه رؤية جميع الوصفات
        pass
    elif any(role.name == 'doctor' for role in current_user.roles):
        # الطبيب يرى الوصفات التي كتبها فقط
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        if doctor:
            query = query.filter(Prescription.doctor_id == doctor.id)
        else:
            return jsonify({
                'message': 'لم يتم العثور على بيانات الطبيب!',
                'message_en': 'Doctor data not found!'
            }), 404
    elif any(role.name in ['nurse', 'pharmacist'] for role in current_user.roles):
        # الممرض والصيدلي يرون جميع الوصفات
        pass
    else:
        # المريض يرى وصفاته فقط
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        if patient:
            query = query.join(Visit.appointment).filter(Appointment.patient_id == patient.id)
        else:
            return jsonify({
                'message': 'لم يتم العثور على بيانات المريض!',
                'message_en': 'Patient data not found!'
            }), 404
    
    # تطبيق التصفية حسب المعايير
    if patient_id:
        query = query.join(Visit.appointment).filter(Appointment.patient_id == patient_id)
    if doctor_id:
        query = query.filter(Prescription.doctor_id == doctor_id)
    if start_date:
        query = query.filter(Prescription.prescription_date >= start_date)
    if end_date:
        query = query.filter(Prescription.prescription_date <= end_date)
    
    # ترتيب الوصفات حسب التاريخ (الأحدث أولاً)
    query = query.order_by(Prescription.prescription_date.desc())
    
    prescriptions = query.paginate(page=page, per_page=per_page, error_out=False)
    
    prescriptions_list = []
    for prescription in prescriptions.items:
        visit = prescription.visit
        appointment = visit.appointment
        prescriptions_list.append({
            'id': prescription.id,
            'visit_id': prescription.visit_id,
            'doctor_id': prescription.doctor_id,
            'doctor_name': f"د. {prescription.doctor.user.first_name} {prescription.doctor.user.last_name}",
            'doctor_name_ar': f"د. {prescription.doctor.user.first_name_ar or ''} {prescription.doctor.user.last_name_ar or ''}",
            'patient_id': appointment.patient_id,
            'patient_name': f"{appointment.patient.user.first_name} {appointment.patient.user.last_name}",
            'patient_name_ar': f"{appointment.patient.user.first_name_ar or ''} {appointment.patient.user.last_name_ar or ''}",
            'prescription_date': prescription.prescription_date.isoformat(),
            'status': prescription.status,
            'status_ar': prescription.status_ar,
            'created_at': prescription.created_at.isoformat()
        })
    
    return jsonify({
        'prescriptions': prescriptions_list,
        'total': prescriptions.total,
        'pages': prescriptions.pages,
        'current_page': prescriptions.page
    }), 200

# الحصول على وصفة طبية محددة بواسطة المعرف
@prescription_bp.route('/<int:prescription_id>', methods=['GET'])
@token_required
def get_prescription(current_user, prescription_id):
    prescription = Prescription.query.get_or_404(prescription_id)
    visit = prescription.visit
    appointment = visit.appointment
    
    # التحقق من الصلاحيات
    if not any(role.name in ['admin', 'nurse', 'pharmacist'] for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        patient = Patient.query.filter_by(user_id=current_user.id).first()
        
        if (doctor and prescription.doctor_id != doctor.id) and (patient and appointment.patient_id != patient.id):
            return jsonify({
                'message': 'غير مصرح لك بالوصول!',
                'message_en': 'Access denied!'
            }), 403
    
    # الحصول على عناصر الوصفة
    prescription_items = PrescriptionItem.query.filter_by(prescription_id=prescription.id).all()
    items_list = []
    for item in prescription_items:
        items_list.append({
            'id': item.id,
            'medication_name': item.medication_name,
            'medication_name_ar': item.medication_name_ar,
            'dosage': item.dosage,
            'dosage_ar': item.dosage_ar,
            'frequency': item.frequency,
            'frequency_ar': item.frequency_ar,
            'duration': item.duration,
            'duration_ar': item.duration_ar,
            'instructions': item.instructions,
            'instructions_ar': item.instructions_ar
        })
    
    return jsonify({
        'id': prescription.id,
        'visit_id': prescription.visit_id,
        'doctor_id': prescription.doctor_id,
        'doctor_name': f"د. {prescription.doctor.user.first_name} {prescription.doctor.user.last_name}",
        'doctor_name_ar': f"د. {prescription.doctor.user.first_name_ar or ''} {prescription.doctor.user.last_name_ar or ''}",
        'patient_id': appointment.patient_id,
        'patient_name': f"{appointment.patient.user.first_name} {appointment.patient.user.last_name}",
        'patient_name_ar': f"{appointment.patient.user.first_name_ar or ''} {appointment.patient.user.last_name_ar or ''}",
        'prescription_date': prescription.prescription_date.isoformat(),
        'status': prescription.status,
        'status_ar': prescription.status_ar,
        'notes': prescription.notes,
        'notes_ar': prescription.notes_ar,
        'items': items_list,
        'created_at': prescription.created_at.isoformat(),
        'updated_at': prescription.updated_at.isoformat()
    }), 200

# إنشاء وصفة طبية جديدة
@prescription_bp.route('/', methods=['POST'])
@token_required
@role_required(['admin', 'doctor'])
def create_prescription(current_user):
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    if not data.get('visit_id'):
        return jsonify({
            'message': 'معرف الزيارة مطلوب!',
            'message_en': 'Visit ID is required!'
        }), 400
    
    if not data.get('items') or not isinstance(data.get('items'), list) or len(data.get('items')) == 0:
        return jsonify({
            'message': 'يجب توفير عنصر واحد على الأقل للوصفة!',
            'message_en': 'At least one prescription item is required!'
        }), 400
    
    # التحقق من وجود الزيارة
    visit = Visit.query.get(data.get('visit_id'))
    if not visit:
        return jsonify({
            'message': 'الزيارة غير موجودة!',
            'message_en': 'Visit not found!'
        }), 404
    
    # التحقق من الصلاحيات للطبيب
    doctor_id = None
    if any(role.name == 'doctor' for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        if doctor:
            doctor_id = doctor.id
            # التحقق من أن الطبيب هو نفسه طبيب الموعد
            if visit.appointment.doctor_id != doctor.id:
                return jsonify({
                    'message': 'غير مصرح لك بإنشاء وصفة لهذه الزيارة!',
                    'message_en': 'You are not authorized to create a prescription for this visit!'
                }), 403
        else:
            return jsonify({
                'message': 'لم يتم العثور على بيانات الطبيب!',
                'message_en': 'Doctor data not found!'
            }), 404
    else:
        # للمدير، استخدام طبيب الموعد
        doctor_id = visit.appointment.doctor_id
    
    # إنشاء وصفة طبية جديدة
    new_prescription = Prescription(
        visit_id=data.get('visit_id'),
        doctor_id=doctor_id,
        prescription_date=data.get('prescription_date'),
        status=data.get('status', 'active'),
        status_ar=data.get('status_ar', 'نشط'),
        notes=data.get('notes'),
        notes_ar=data.get('notes_ar')
    )
    
    db.session.add(new_prescription)
    db.session.flush()  # للحصول على معرف الوصفة
    
    # إضافة عناصر الوصفة
    for item_data in data.get('items'):
        new_item = PrescriptionItem(
            prescription_id=new_prescription.id,
            medication_name=item_data.get('medication_name'),
            medication_name_ar=item_data.get('medication_name_ar'),
            dosage=item_data.get('dosage'),
            dosage_ar=item_data.get('dosage_ar'),
            frequency=item_data.get('frequency'),
            frequency_ar=item_data.get('frequency_ar'),
            duration=item_data.get('duration'),
            duration_ar=item_data.get('duration_ar'),
            instructions=item_data.get('instructions'),
            instructions_ar=item_data.get('instructions_ar')
        )
        db.session.add(new_item)
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم إنشاء الوصفة الطبية بنجاح!',
        'message_en': 'Prescription created successfully!',
        'prescription_id': new_prescription.id
    }), 201

# تحديث وصفة طبية
@prescription_bp.route('/<int:prescription_id>', methods=['PUT'])
@token_required
@role_required(['admin', 'doctor'])
def update_prescription(current_user, prescription_id):
    prescription = Prescription.query.get_or_404(prescription_id)
    
    # التحقق من الصلاحيات للطبيب
    if any(role.name == 'doctor' for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        if doctor and prescription.doctor_id != doctor.id:
            return jsonify({
                'message': 'غير مصرح لك بتحديث هذه الوصفة!',
                'message_en': 'You are not authorized to update this prescription!'
            }), 403
    
    data = request.get_json()
    
    # تحديث البيانات المسموح بها
    if data.get('status'):
        prescription.status = data.get('status')
    if data.get('status_ar'):
        prescription.status_ar = data.get('status_ar')
    if data.get('notes'):
        prescription.notes = data.get('notes')
    if data.get('notes_ar'):
        prescription.notes_ar = data.get('notes_ar')
    
    # تحديث عناصر الوصفة إذا تم توفيرها
    if data.get('items') and isinstance(data.get('items'), list) and len(data.get('items')) > 0:
        # حذف العناصر الحالية
        PrescriptionItem.query.filter_by(prescription_id=prescription.id).delete()
        
        # إضافة العناصر الجديدة
        for item_data in data.get('items'):
            new_item = PrescriptionItem(
                prescription_id=prescription.id,
                medication_name=item_data.get('medication_name'),
                medication_name_ar=item_data.get('medication_name_ar'),
                dosage=item_data.get('dosage'),
                dosage_ar=item_data.get('dosage_ar'),
                frequency=item_data.get('frequency'),
                frequency_ar=item_data.get('frequency_ar'),
                duration=item_data.get('duration'),
                duration_ar=item_data.get('duration_ar'),
                instructions=item_data.get('instructions'),
                instructions_ar=item_data.get('instructions_ar')
            )
            db.session.add(new_item)
    
    db.session.commit()
    
    return jsonify({
        'message': 'تم تحديث الوصفة الطبية بنجاح!',
        'message_en': 'Prescription updated successfully!'
    }), 200

# حذف وصفة طبية (للمدير فقط)
@prescription_bp.route('/<int:prescription_id>', methods=['DELETE'])
@token_required
@role_required(['admin'])
def delete_prescription(current_user, prescription_id):
    prescription = Prescription.query.get_or_404(prescription_id)
    
    db.session.delete(prescription)
    db.session.commit()
    
    return jsonify({
        'message': 'تم حذف الوصفة الطبية بنجاح!',
        'message_en': 'Prescription deleted successfully!'
    }), 200

# إضافة عنصر جديد للوصفة
@prescription_bp.route('/<int:prescription_id>/items', methods=['POST'])
@token_required
@role_required(['admin', 'doctor'])
def add_prescription_item(current_user, prescription_id):
    prescription = Prescription.query.get_or_404(prescription_id)
    
    # التحقق من الصلاحيات للطبيب
    if any(role.name == 'doctor' for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        if doctor and prescription.doctor_id != doctor.id:
            return jsonify({
                'message': 'غير مصرح لك بتعديل هذه الوصفة!',
                'message_en': 'You are not authorized to modify this prescription!'
            }), 403
    
    data = request.get_json()
    
    # التحقق من البيانات المطلوبة
    required_fields = ['medication_name', 'dosage', 'frequency', 'duration']
    for field in required_fields:
        if not data.get(field):
            return jsonify({
                'message': f'حقل {field} مطلوب!',
                'message_en': f'Field {field} is required!'
            }), 400
    
    # إضافة عنصر جديد
    new_item = PrescriptionItem(
        prescription_id=prescription.id,
        medication_name=data.get('medication_name'),
        medication_name_ar=data.get('medication_name_ar'),
        dosage=data.get('dosage'),
        dosage_ar=data.get('dosage_ar'),
        frequency=data.get('frequency'),
        frequency_ar=data.get('frequency_ar'),
        duration=data.get('duration'),
        duration_ar=data.get('duration_ar'),
        instructions=data.get('instructions'),
        instructions_ar=data.get('instructions_ar')
    )
    
    db.session.add(new_item)
    db.session.commit()
    
    return jsonify({
        'message': 'تم إضافة العنصر بنجاح!',
        'message_en': 'Item added successfully!',
        'item_id': new_item.id
    }), 201

# حذف عنصر من الوصفة
@prescription_bp.route('/<int:prescription_id>/items/<int:item_id>', methods=['DELETE'])
@token_required
@role_required(['admin', 'doctor'])
def delete_prescription_item(current_user, prescription_id, item_id):
    prescription = Prescription.query.get_or_404(prescription_id)
    
    # التحقق من الصلاحيات للطبيب
    if any(role.name == 'doctor' for role in current_user.roles):
        doctor = Doctor.query.filter_by(user_id=current_user.id).first()
        if doctor and prescription.doctor_id != doctor.id:
            return jsonify({
                'message': 'غير مصرح لك بتعديل هذه الوصفة!',
                'message_en': 'You are not authorized to modify this prescription!'
            }), 403
    
    item = PrescriptionItem.query.get_or_404(item_id)
    
    # التحقق من أن العنصر ينتمي للوصفة المحددة
    if item.prescription_id != prescription.id:
        return jsonify({
            'message': 'العنصر غير موجود في هذه الوصفة!',
            'message_en': 'Item not found in this prescription!'
        }), 404
    
    db.session.delete(item)
    db.session.commit()
    
    return jsonify({
        'message': 'تم حذف العنصر بنجاح!',
        'message_en': 'Item deleted successfully!'
    }), 200
